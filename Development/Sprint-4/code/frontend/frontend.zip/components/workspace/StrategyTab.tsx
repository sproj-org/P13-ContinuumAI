﻿"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useParams } from "next/navigation";
import { AlertTriangle, BarChart3, Plus, RefreshCw, Save, Trash2, X } from "lucide-react";

import { ApiRequestError, apiClient } from "@/lib/api";
import DecisionIntelligencePanel from "@/components/workspace/DecisionIntelligencePanel";
import type { AnalysisContext } from "@/lib/types/analysis";
import type { ChartSemanticContext } from "@/lib/types/chartspec";
import type {
  CoverageGap,
  DecisionStateResponse,
  StrategyAgentPatch,
  StrategyAgentMissingItem,
  StrategyContextPayload,
  StrategyDecisionSignalsResponse,
  StrategyEvaluationKpiResult,
  StrategyEvaluationResponse,
  StrategyKpi,
  StrategyKpiLibraryResponse,
  StrategyPillarPayload,
  StrategyRule,
  StrategyRulesResponse,
  StrategySwotPayload,
  StrategyTarget,
  StrategyTargetsResponse,
} from "@/lib/api-types";
import { useAuth } from "@/lib/auth-context";
import { useAppStore } from "@/lib/store";

type Section = "overview" | "kpi_library" | "targets" | "rules" | "reconciliation" | "evaluation" | "advanced_yaml";
type EditorMode = "base" | "override";
type EditorKind = "strategy" | "kpi";
type KpiFormMode = "create" | "edit" | "duplicate";
type TargetFormMode = "create" | "edit";
type RuleFormMode = "create" | "edit";

type RuleDraft = {
  id: string;
  kpi_id: string;
  operator: "<" | "<=" | ">" | ">=" | "==";
  threshold: string;
  severity: "info" | "warn" | "block";
  action: string;
  rationale: string;
  ai_suggested?: boolean | null;
  source?: string | null;
};

const sections: Array<{ id: Section; label: string }> = [
  { id: "overview", label: "Overview" },
  { id: "kpi_library", label: "KPI Library" },
  { id: "targets", label: "Targets" },
  { id: "rules", label: "Rules" },
  { id: "reconciliation", label: "Reconciliation" },
  { id: "evaluation", label: "Evaluation" },
  { id: "advanced_yaml", label: "Advanced YAML" },
];

const sectionGuidance: Record<Section, { title: string; body: string }> = {
  overview: {
    title: "Frame the decision system",
    body: "Capture the north star, pillars, SWOT context, and readiness gaps so downstream KPI, target, and rule work stays traceable.",
  },
  kpi_library: {
    title: "Map strategy to data",
    body: "Use Inspect in Analytics to open a KPI in the Chart Builder with its most likely mart and field mapping.",
  },
  targets: {
    title: "Turn KPIs into thresholds",
    body: "Targets define what good looks like. Evaluation and decision signals use these thresholds to classify KPI health.",
  },
  rules: {
    title: "Translate signals into action",
    body: "Rules connect KPI conditions to operational guidance. Keep thresholds explicit and reference the KPI IDs they protect.",
  },
  reconciliation: {
    title: "Close strategy-data gaps",
    body: "Use reconciliation notes to extract candidate KPIs, inspect missing marts or columns, and apply only safe patches.",
  },
  evaluation: {
    title: "Review live decision posture",
    body: "Run evaluation to compare actuals versus targets, inspect failing KPIs in analytics, and review triggered rules together.",
  },
  advanced_yaml: {
    title: "Fallback for bulk edits",
    body: "Use YAML for advanced changes only. Structured sections remain the safer path for routine strategy maintenance.",
  },
};

function scoreText(value: number): string {
  return `${(value * 100).toFixed(1)}%`;
}

function emptyKpi(): StrategyKpi {
  return {
    id: "",
    display_name: "",
    description: "",
    formula: "sum(net_sales)",
    marts: [],
    required_columns: [],
    dimensions: [],
    default_grain: "day",
    pillar_id: "",
    owner: "",
    semantic_family: "",
    business_concepts: [],
    metric_aliases: [],
    preferred_drill_path: [],
    mart_drill_overrides: {},
    terminal_dimensions: [],
    disallowed_drill_dimensions: [],
    preferred_chart_types: [],
    derived_metrics: {},
  };
}

function normalizeKpi(kpi: StrategyKpi): StrategyKpi {
  const clean = (value: string | null | undefined) => (value || "").trim() || null;
  return {
    id: (kpi.id || "").trim(),
    display_name: clean(kpi.display_name),
    description: (kpi.description || "").trim(),
    formula: (kpi.formula || "").trim(),
    marts: (kpi.marts || []).map((item) => item.trim()).filter(Boolean),
    required_columns: (kpi.required_columns || []).map((item) => item.trim()).filter(Boolean),
    dimensions: (kpi.dimensions || []).map((item) => item.trim()).filter(Boolean),
    default_grain: clean(kpi.default_grain),
    pillar_id: clean(kpi.pillar_id),
    owner: clean(kpi.owner),
    semantic_family: clean(kpi.semantic_family),
    business_concepts: (kpi.business_concepts || []).map((item) => item.trim()).filter(Boolean),
    metric_aliases: (kpi.metric_aliases || []).map((item) => item.trim()).filter(Boolean),
    preferred_drill_path: (kpi.preferred_drill_path || []).map((item) => item.trim()).filter(Boolean),
    mart_drill_overrides: Object.fromEntries(
      Object.entries(kpi.mart_drill_overrides || {})
        .map(([martId, path]) => [
          martId.trim(),
          (path || []).map((item) => item.trim()).filter(Boolean),
        ])
        .filter(([martId, path]) => Boolean(martId) && path.length > 0)
    ),
    terminal_dimensions: (kpi.terminal_dimensions || []).map((item) => item.trim()).filter(Boolean),
    disallowed_drill_dimensions: (kpi.disallowed_drill_dimensions || []).map((item) => item.trim()).filter(Boolean),
    preferred_chart_types: (kpi.preferred_chart_types || []).filter(Boolean),
    derived_metrics: Object.fromEntries(
      Object.entries(kpi.derived_metrics || {})
        .map(([key, formula]) => [key.trim(), (formula || "").trim()])
        .filter(([key, formula]) => Boolean(key) && Boolean(formula))
    ),
  };
}

function gapSummary(gap: CoverageGap): string {
  const missingMarts = gap.details?.missing_marts ?? [];
  const missingColumnsByMart = gap.details?.missing_columns_by_mart ?? {};
  const parts: string[] = [];
  if (missingMarts.length > 0) {
    parts.push(`Missing marts: ${missingMarts.join(", ")}`);
  }
  const columnParts = Object.entries(missingColumnsByMart)
    .map(([mart, cols]) => `${mart}: ${cols.join(", ")}`)
    .filter(Boolean);
  if (columnParts.length > 0) {
    parts.push(`Missing columns: ${columnParts.join(" | ")}`);
  }
  return parts.join(". ") || "No details";
}

function missingSummary(item: StrategyAgentMissingItem): string {
  const parts: string[] = [];
  const missingMarts = item.details?.missing_marts ?? [];
  const missingColumns = item.details?.missing_columns_by_mart ?? {};
  if (missingMarts.length > 0) {
    parts.push(`Missing marts: ${missingMarts.join(", ")}`);
  }
  const columnParts = Object.entries(missingColumns)
    .map(([mart, cols]) => `${mart}: ${cols.join(", ")}`)
    .filter(Boolean);
  if (columnParts.length > 0) {
    parts.push(`Missing columns: ${columnParts.join(" | ")}`);
  }
  return parts.join(". ");
}

function linesToList(value: string): string[] {
  return value
    .split("\n")
    .map((item) => item.trim())
    .filter(Boolean);
}

function listToLines(value: string[] | undefined | null): string {
  return (value || []).join("\n");
}

function extractRuleReferences(condition: string): string[] {
  const regex = /(?:kpi|target)\(\s*["']([^"']+)["']\s*\)/g;
  const refs = new Set<string>();
  let match = regex.exec(condition);
  while (match) {
    refs.add(match[1]);
    match = regex.exec(condition);
  }
  return Array.from(refs);
}

function extractFormulaColumns(formula: string | null | undefined): string[] {
  const reserved = new Set([
    "sum",
    "avg",
    "count",
    "min",
    "max",
    "case",
    "when",
    "then",
    "else",
    "end",
    "and",
    "or",
    "not",
    "null",
    "coalesce",
    "round",
    "abs",
  ]);
  const matches = (formula || "").match(/[a-zA-Z_][a-zA-Z0-9_]*/g) ?? [];
  return Array.from(
    new Set(matches.filter((token) => !reserved.has(token.toLowerCase())))
  );
}

function inferAggregationFromFormula(formula: string | null | undefined): "sum" | "avg" | "count" | "min" | "max" {
  const normalized = (formula || "").toLowerCase();
  if (normalized.includes("count(")) return "count";
  if (normalized.includes("avg(")) return "avg";
  if (normalized.includes("min(")) return "min";
  if (normalized.includes("max(")) return "max";
  return "sum";
}

function looksTemporal(column: string): boolean {
  return /date|day|week|month|quarter|year/i.test(column);
}

type AnalyticsLaunchInput = Pick<StrategyKpi, "id" | "display_name" | "formula" | "marts" | "required_columns" | "dimensions">;
type StrategyAnalysisInput = {
  id: string;
  display_name?: string | null;
  formula?: string | null;
  marts?: string[];
  required_columns?: string[];
  dimensions?: string[];
} & Partial<StrategyEvaluationKpiResult>;
type AnalyticsLaunchConfig = {
  martId: string;
  chartType: "bar" | "line" | "histogram";
  xAxis: string | null;
  yAxis: string;
  aggregationFn: "sum" | "avg" | "count" | "min" | "max";
  title: string;
};

function buildAnalyticsLaunchConfig(
  item: AnalyticsLaunchInput,
  martColumns: Record<string, string[]>,
): AnalyticsLaunchConfig | null {
  const formulaColumns = extractFormulaColumns(item.formula);
  const aggregationFn = inferAggregationFromFormula(item.formula);

  for (const martId of item.marts || []) {
    const columns = martColumns[martId] || [];
    if (columns.length === 0) {
      continue;
    }

    const dimensionCandidates = (item.dimensions || []).filter((column) => columns.includes(column));
    const measureCandidate =
      formulaColumns.find((column) => columns.includes(column) && !dimensionCandidates.includes(column)) ||
      (item.required_columns || []).find((column) => columns.includes(column) && !dimensionCandidates.includes(column)) ||
      null;

    if (!measureCandidate) {
      continue;
    }

    const temporalCandidate = columns.find((column) => looksTemporal(column));
    const xAxis = dimensionCandidates[0] || temporalCandidate || null;
    const chartType: AnalyticsLaunchConfig["chartType"] = xAxis
      ? (looksTemporal(xAxis) ? "line" : "bar")
      : "histogram";

    return {
      martId,
      chartType,
      xAxis,
      yAxis: measureCandidate,
      aggregationFn,
      title: item.display_name || item.id,
    };
  }

  return null;
}

function humanizeIdentifier(value: string | null | undefined): string {
  const text = (value || "").trim();
  if (!text) {
    return "Unknown";
  }
  return text
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function formatScalar(value: unknown): string | null {
  if (typeof value === "number") {
    return Number.isInteger(value) ? String(value) : value.toFixed(2);
  }
  if (typeof value === "string" && value.trim()) {
    return value.trim();
  }
  return null;
}

function describePatch(
  patch: StrategyAgentPatch,
  kpiLabelById: Map<string, string>,
): { title: string; subtitle: string | null; summary: string } {
  const after = patch.after || {};
  const before = patch.before || {};
  const resolveKpiLabel = (kpiId: string | null | undefined, fallback?: string | null) => {
    const key = (kpiId || "").trim();
    if (key && kpiLabelById.has(key)) {
      return kpiLabelById.get(key) as string;
    }
    const fallbackValue = (fallback || "").trim();
    return fallbackValue || humanizeIdentifier(key);
  };

  if (patch.type === "add_kpi") {
    const kpi = typeof after.kpi === "object" && after.kpi !== null ? (after.kpi as StrategyKpi) : null;
    const label = resolveKpiLabel(kpi?.id, kpi?.display_name || kpi?.id || patch.target_id);
    const marts = (kpi?.marts || []).join(", ");
    const dimensions = (kpi?.dimensions || []).join(", ");
    const owner = formatScalar(kpi?.owner);
    const subtitle = [owner ? `Owner ${owner}` : null, kpi?.pillar_id ? `Pillar ${humanizeIdentifier(kpi.pillar_id)}` : null]
      .filter(Boolean)
      .join(" • ");
    const summary = [
      kpi?.formula ? `Formula ${kpi.formula}` : null,
      marts ? `Marts ${marts}` : null,
      dimensions ? `Dimensions ${dimensions}` : null,
    ]
      .filter(Boolean)
      .join(" • ");
    return {
      title: `Add KPI: ${label}`,
      subtitle: subtitle || null,
      summary: summary || "Create a new KPI in the registry.",
    };
  }

  if (patch.type === "set_target") {
    const target =
      typeof after.target === "object" && after.target !== null ? (after.target as Record<string, unknown>) : null;
    const kpiId = typeof target?.kpi_id === "string" ? target.kpi_id : patch.target_id;
    const label = resolveKpiLabel(kpiId, kpiId);
    const subtitle = [formatScalar(target?.owner) ? `Owner ${formatScalar(target?.owner)}` : null, formatScalar(target?.horizon) ? `Horizon ${formatScalar(target?.horizon)}` : null]
      .filter(Boolean)
      .join(" • ");
    const summary = [
      formatScalar(target?.target_value) ? `Target ${formatScalar(target?.target_value)}` : null,
      formatScalar(target?.yellow_threshold) ? `Yellow ${formatScalar(target?.yellow_threshold)}` : null,
      formatScalar(target?.red_threshold) ? `Red ${formatScalar(target?.red_threshold)}` : null,
      formatScalar(target?.direction) ? `Direction ${formatScalar(target?.direction)}` : null,
    ]
      .filter(Boolean)
      .join(" • ");
    return {
      title: `Set Target for KPI: ${label}`,
      subtitle: subtitle || null,
      summary: summary || "Seed a target threshold for this KPI.",
    };
  }

  if (patch.type === "add_rule") {
    const rule = typeof after.rule === "object" && after.rule !== null ? (after.rule as Record<string, unknown>) : null;
    const referencedKpiId = extractRuleReferences(typeof rule?.condition === "string" ? rule.condition : "")[0] || patch.target_id;
    const label = resolveKpiLabel(referencedKpiId, referencedKpiId);
    const subtitle = [
      formatScalar(rule?.severity) ? `Severity ${String(formatScalar(rule?.severity)).toUpperCase()}` : null,
      formatScalar(rule?.id) ? `Rule ${formatScalar(rule?.id)}` : null,
    ]
      .filter(Boolean)
      .join(" • ");
    const summary = [
      typeof rule?.condition === "string" && rule.condition.trim() ? `When ${rule.condition.trim()}` : null,
      typeof rule?.action === "string" && rule.action.trim() ? `Action ${rule.action.trim()}` : null,
    ]
      .filter(Boolean)
      .join(" • ");
    return {
      title: `Add Rule for KPI: ${label}`,
      subtitle: subtitle || null,
      summary: summary || "Add a new decision rule for this KPI.",
    };
  }

  if (patch.type === "replace_column") {
    const details = after as Record<string, unknown>;
    const kpiId = typeof details.kpi_id === "string" ? details.kpi_id : patch.target_id;
    const label = resolveKpiLabel(kpiId, kpiId);
    const mart = formatScalar(details.mart);
    const fromColumn = formatScalar(details.from_column) || formatScalar((before as Record<string, unknown>).column);
    const toColumn = formatScalar(details.to_column);
    return {
      title: `Replace Column for KPI: ${label}`,
      subtitle: mart ? `Mart ${mart}` : null,
      summary:
        fromColumn && toColumn
          ? `Swap ${fromColumn} -> ${toColumn}${mart ? ` in ${mart}` : ""}.`
          : "Update the KPI to use an available column.",
    };
  }

  if (patch.type === "update_formula") {
    const formula = formatScalar((after as Record<string, unknown>).formula);
    const label = resolveKpiLabel(patch.target_id, patch.target_id);
    return {
      title: `Update Formula for KPI: ${label}`,
      subtitle: null,
      summary: formula ? `New formula ${formula}` : "Update the KPI formula.",
    };
  }

  return {
    title: `${humanizeIdentifier(patch.type)}: ${humanizeIdentifier(patch.target_id)}`,
    subtitle: null,
    summary: "Apply a compatibility patch to the strategy layer.",
  };
}

export default function StrategyTab() {
  const params = useParams<{ datasetId: string }>();
  const datasetId = params?.datasetId ?? "silkroute";
  const { user } = useAuth();
  const { setActiveTab, setSelectedAggregation, setChartConfig, setChartBuilderSeed } = useAppStore();

  const [section, setSection] = useState<Section>("overview");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const [decision, setDecision] = useState<DecisionStateResponse | null>(null);
  const [kpiLibrary, setKpiLibrary] = useState<StrategyKpiLibraryResponse | null>(null);

  const [strategyBaseYaml, setStrategyBaseYaml] = useState("");
  const [strategyOverrideYaml, setStrategyOverrideYaml] = useState("");
  const [kpiBaseYaml, setKpiBaseYaml] = useState("");
  const [kpiOverrideYaml, setKpiOverrideYaml] = useState("");
  const [strategyMode, setStrategyMode] = useState<EditorMode>("base");
  const [kpiMode, setKpiMode] = useState<EditorMode>("base");
  const [editor, setEditor] = useState<EditorKind>("strategy");
  const [strategyText, setStrategyText] = useState("");
  const [kpiText, setKpiText] = useState("");
  const [yamlValidationMessage, setYamlValidationMessage] = useState<string | null>(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [formMode, setFormMode] = useState<KpiFormMode>("create");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<StrategyKpi>(emptyKpi());
  const [dimensionsDraft, setDimensionsDraft] = useState("");
  const [derivedMetricsDraft, setDerivedMetricsDraft] = useState("");
  const [kpiSearch, setKpiSearch] = useState("");
  const [strategyNotes, setStrategyNotes] = useState("");
  const [agentCandidates, setAgentCandidates] = useState<StrategyKpi[]>([]);
  const [agentNotes, setAgentNotes] = useState<string[]>([]);
  const [agentPatches, setAgentPatches] = useState<StrategyAgentPatch[]>([]);
  const [selectedPatchIds, setSelectedPatchIds] = useState<string[]>([]);
  const [agentMissingById, setAgentMissingById] = useState<Record<string, string>>({});
  const [agentColumnMatchesById, setAgentColumnMatchesById] = useState<Record<string, string[]>>({});
  const [ignoredCandidateIds, setIgnoredCandidateIds] = useState<string[]>([]);
  const [agentLoading, setAgentLoading] = useState(false);
  const [agentApplying, setAgentApplying] = useState(false);
  const [agentUndoing, setAgentUndoing] = useState(false);
  const [lastApplyBaseRevision, setLastApplyBaseRevision] = useState<string | null>(null);
  const [addingCandidateId, setAddingCandidateId] = useState<string | null>(null);
  const [overviewRevision, setOverviewRevision] = useState<string | null>(null);
  const [strategyContextDraft, setStrategyContextDraft] = useState<StrategyContextPayload>({
    company: "",
    horizon: "",
    north_star_metric: "",
    narrative: "",
  });
  const [pillarsDraft, setPillarsDraft] = useState<StrategyPillarPayload[]>([]);
  const [swotText, setSwotText] = useState({
    strengths: "",
    weaknesses: "",
    opportunities: "",
    threats: "",
  });
  const [targetsState, setTargetsState] = useState<StrategyTargetsResponse | null>(null);
  const [targetPillarFilter, setTargetPillarFilter] = useState<string>("all");
  const [targetOwnerFilter, setTargetOwnerFilter] = useState<string>("all");
  const [targetModalOpen, setTargetModalOpen] = useState(false);
  const [targetFormMode, setTargetFormMode] = useState<TargetFormMode>("create");
  const [targetDraft, setTargetDraft] = useState<StrategyTarget>({
    kpi_id: "",
    target_value: 0,
    red_threshold: null,
    yellow_threshold: null,
    direction: "up",
    owner: "",
    horizon: "",
  });
  const [rulesState, setRulesState] = useState<StrategyRulesResponse | null>(null);
  const [ruleSeverityFilter, setRuleSeverityFilter] = useState<"all" | "block" | "warn" | "info">("all");
  const [ruleModalOpen, setRuleModalOpen] = useState(false);
  const [ruleFormMode, setRuleFormMode] = useState<RuleFormMode>("create");
  const [ruleDraft, setRuleDraft] = useState<RuleDraft>({
    id: "",
    kpi_id: "",
    operator: "<",
    threshold: "",
    severity: "warn",
    action: "",
    rationale: "",
    ai_suggested: null,
    source: null,
  });
  const [evaluationState, setEvaluationState] = useState<StrategyEvaluationResponse | null>(null);
  const [decisionSignalsState, setDecisionSignalsState] = useState<StrategyDecisionSignalsResponse | null>(null);
  const [evaluationLoading, setEvaluationLoading] = useState(false);
  const [selectedEvaluationKpi, setSelectedEvaluationKpi] = useState<StrategyEvaluationKpiResult | null>(null);

  const revision = kpiLibrary?.revision ?? decision?.revision ?? null;
  const readiness = decision?.readiness;
  const kpisDefined = decision?.readiness_flags?.kpis_defined ?? true;
  const targetsDefined = decision?.readiness_flags?.targets_defined ?? false;
  const rulesDefined = decision?.readiness_flags?.rules_defined ?? false;
  const kpis = kpiLibrary?.kpis ?? [];
  const kpiLabelById = useMemo(() => {
    const map = new Map<string, string>();
    for (const item of kpis) {
      map.set(item.id, item.display_name?.trim() || item.id);
    }
    return map;
  }, [kpis]);
  const availableMarts = kpiLibrary?.available_marts ?? [];
  const martColumns = kpiLibrary?.mart_columns ?? {};
  const targets = targetsState?.targets ?? [];

  const targetByKpiId = useMemo(() => {
    const map = new Map<string, StrategyTarget>();
    for (const item of targets) {
      map.set(item.kpi_id, item);
    }
    return map;
  }, [targets]);
  const rules = rulesState?.rules ?? [];
  const knownRuleKpis = useMemo(() => new Set(rulesState?.available_kpis || []), [rulesState]);
  const kpiById = useMemo(() => {
    const map = new Map<string, StrategyKpi>();
    for (const item of kpis) {
      map.set(item.id, item);
    }
    return map;
  }, [kpis]);
  const evaluationByKpiId = useMemo(() => {
    const map = new Map<string, StrategyEvaluationKpiResult>();
    for (const item of evaluationState?.kpis || []) {
      map.set(item.id, item);
    }
    return map;
  }, [evaluationState]);
  const buildStrategyAnalysisContext = useCallback(
    (
      item: StrategyAnalysisInput,
      analyticsConfig?: AnalyticsLaunchConfig | null,
    ): AnalysisContext => {
      const libraryKpi = kpiById.get(item.id);
      const evaluationKpi = evaluationByKpiId.get(item.id) || (item as StrategyEvaluationKpiResult);
      const target = targetByKpiId.get(item.id);
      const triggeredRules = (evaluationState?.triggered_rules || []).filter((rule) => (rule.affected_kpis || []).includes(item.id));
      const matchedLabel = libraryKpi?.display_name || item.display_name || item.id;
      const matchedMarts = libraryKpi?.marts || item.marts || [];
      const preferredMart = analyticsConfig?.martId || matchedMarts[0] || null;
      const preferredDrillPath =
        (preferredMart && libraryKpi?.mart_drill_overrides?.[preferredMart]) ||
        libraryKpi?.preferred_drill_path ||
        item.dimensions ||
        [];

      return {
        source: "strategy",
        chart_title: matchedLabel,
        chart_family: analyticsConfig?.chartType || "bar",
        table: preferredMart,
        semantic: {
          matched_kpi_id: item.id,
          matched_kpi_label: matchedLabel,
          semantic_family: libraryKpi?.semantic_family || null,
          marts: matchedMarts,
          required_columns: libraryKpi?.required_columns || item.required_columns || [],
          dimensions: libraryKpi?.dimensions || item.dimensions || [],
          metric_aliases: libraryKpi?.metric_aliases || [],
          business_concepts: libraryKpi?.business_concepts || [],
          preferred_drill_path: preferredDrillPath,
          mart_hierarchy: preferredDrillPath,
          terminal_dimensions: libraryKpi?.terminal_dimensions || [],
          disallowed_drill_dimensions: libraryKpi?.disallowed_drill_dimensions || [],
          preferred_chart_types: libraryKpi?.preferred_chart_types || [],
          default_grain:
            (libraryKpi?.default_grain as "day" | "week" | "month" | "quarter" | "year" | null | undefined) || null,
          metric_field_hint: analyticsConfig?.yAxis || libraryKpi?.required_columns?.[0] || null,
          entity_field_hint: libraryKpi?.terminal_dimensions?.[0] || null,
          time_field_hint: analyticsConfig?.chartType === "line" ? analyticsConfig.xAxis : null,
        },
        strategy: {
          target_value: evaluationKpi?.target ?? target?.target_value ?? null,
          target_direction: target?.direction ?? null,
          target_horizon: target?.horizon ?? null,
          current_value: evaluationKpi?.value ?? null,
          variance: evaluationKpi?.variance ?? null,
          status: evaluationKpi?.status ?? null,
          triggered_rules: triggeredRules.map((rule) => `${rule.id}: ${rule.action}`),
          triggered_rule_actions: triggeredRules.map((rule) => rule.action),
          provenance: evaluationKpi?.provenance || {},
        },
      };
    },
    [evaluationByKpiId, evaluationState?.triggered_rules, kpiById, targetByKpiId],
  );
  const selectedKpiAnalysisContext = useMemo(
    () => (selectedEvaluationKpi ? buildStrategyAnalysisContext(selectedEvaluationKpi) : null),
    [buildStrategyAnalysisContext, selectedEvaluationKpi],
  );
  const openInAnalytics = useCallback(
    (item: AnalyticsLaunchInput) => {
      const config = buildAnalyticsLaunchConfig(item, martColumns);
      if (!config) {
        setError(`No compatible analytics mapping was found for KPI '${item.id}'.`);
        return;
      }

      const analysisContext = buildStrategyAnalysisContext(item, config);
      const semanticContext: Partial<ChartSemanticContext> = {
        matched_kpi_id: analysisContext.semantic?.matched_kpi_id ?? null,
        matched_kpi_label: analysisContext.semantic?.matched_kpi_label ?? null,
        semantic_family: analysisContext.semantic?.semantic_family ?? null,
        preferred_drill_path: analysisContext.semantic?.preferred_drill_path ?? [],
        mart_hierarchy: analysisContext.semantic?.mart_hierarchy ?? [],
        terminal_dimensions: analysisContext.semantic?.terminal_dimensions ?? [],
        analysis_context: analysisContext,
        chart_family: config.chartType,
      };

      setSelectedAggregation(config.martId);
      setChartConfig({
        chartType: config.chartType,
        xAxis: config.xAxis,
        yAxis: config.yAxis,
        colorBy: null,
        aggregationFn: config.aggregationFn,
      });
      setChartBuilderSeed({
        filters: [],
        sortTarget: config.xAxis ? "x" : "metric",
        sortDirection: config.chartType === "line" ? "asc" : "desc",
        resultLimit: 20,
        semanticContext,
      });
      setActiveTab("chart-builder");
      setSection("kpi_library");
      setSuccess(`Loaded ${config.title} into Chart Builder using mart '${config.martId}'.`);
    },
    [buildStrategyAnalysisContext, martColumns, setActiveTab, setChartBuilderSeed, setChartConfig, setSelectedAggregation],
  );
  const evaluationSummary = useMemo(() => {
    if (!evaluationState) return null;
    const rows = evaluationState.kpis || [];
    let onTrack = 0;
    let warning = 0;
    let critical = 0;
    for (const row of rows) {
      if (row.status === "green") onTrack += 1;
      else if (row.status === "yellow" || row.status === "no_target") warning += 1;
      else critical += 1;
    }
    return {
      onTrack,
      warning,
      critical,
      triggeredRules: (evaluationState.triggered_rules || []).length,
    };
  }, [evaluationState]);
  const groupedTriggeredRules = useMemo(() => {
    const groups: Record<"critical" | "warn" | "info", StrategyEvaluationResponse["triggered_rules"]> = {
      critical: [],
      warn: [],
      info: [],
    };
    for (const item of evaluationState?.triggered_rules || []) {
      if (item.severity === "block") groups.critical.push(item);
      else if (item.severity === "warn") groups.warn.push(item);
      else groups.info.push(item);
    }
    return groups;
  }, [evaluationState]);
  const targetFilterPillars = useMemo(() => {
    const values = new Set<string>();
    for (const item of kpis) {
      const pillar = (item.pillar_id || "").trim();
      if (pillar) values.add(pillar);
    }
    return Array.from(values).sort((a, b) => a.localeCompare(b));
  }, [kpis]);
  const targetFilterOwners = useMemo(() => {
    const values = new Set<string>();
    for (const item of kpis) {
      const owner = (item.owner || "").trim();
      if (owner) values.add(owner);
    }
    for (const item of targets) {
      const owner = (item.owner || "").trim();
      if (owner) values.add(owner);
    }
    return Array.from(values).sort((a, b) => a.localeCompare(b));
  }, [kpis, targets]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [decisionState, strategyBundle, kpiBundle, kpiState, overviewState, targetState, rulesBundle] = await Promise.all([
        apiClient.getDecisionState(datasetId),
        apiClient.getStrategyBundle(),
        apiClient.getKpiRegistryBundle(),
        apiClient.getStrategyKpis(datasetId),
        apiClient.getStrategyOverview(),
        apiClient.getStrategyTargets(),
        apiClient.getStrategyRules(),
      ]);
      setDecision(decisionState);
      setKpiLibrary(kpiState);
      setStrategyBaseYaml(strategyBundle.base_yaml);
      setStrategyOverrideYaml(strategyBundle.override_yaml);
      setKpiBaseYaml(kpiBundle.base_yaml);
      setKpiOverrideYaml(kpiBundle.override_yaml);
      setStrategyMode("base");
      setKpiMode("base");
      setStrategyText(strategyBundle.base_yaml);
      setKpiText(kpiBundle.base_yaml);
      setOverviewRevision(overviewState.revision);
      setStrategyContextDraft({
        company: overviewState.strategy_context.company || "",
        horizon: overviewState.strategy_context.horizon || "",
        north_star_metric: overviewState.strategy_context.north_star_metric || "",
        narrative: overviewState.strategy_context.narrative || "",
      });
      setPillarsDraft(overviewState.pillars || []);
      const nextSwot: StrategySwotPayload = overviewState.swot || {
        strengths: [],
        weaknesses: [],
        opportunities: [],
        threats: [],
      };
      setSwotText({
        strengths: listToLines(nextSwot.strengths),
        weaknesses: listToLines(nextSwot.weaknesses),
        opportunities: listToLines(nextSwot.opportunities),
        threats: listToLines(nextSwot.threats),
      });
      setTargetsState(targetState);
      setRulesState(rulesBundle);
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Failed to load strategy state");
    } finally {
      setLoading(false);
    }
  }, [datasetId]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    setStrategyText(strategyMode === "base" ? strategyBaseYaml : strategyOverrideYaml);
  }, [strategyBaseYaml, strategyMode, strategyOverrideYaml]);

  useEffect(() => {
    setKpiText(kpiMode === "base" ? kpiBaseYaml : kpiOverrideYaml);
  }, [kpiBaseYaml, kpiMode, kpiOverrideYaml]);

  const draftColumns = useMemo(() => {
    const values = new Set<string>();
    for (const mart of draft.marts || []) {
      for (const column of martColumns[mart] || []) {
        values.add(column);
      }
    }
    return Array.from(values).sort();
  }, [draft.marts, martColumns]);

  const draftDependencyPreview = useMemo(() => {
    return (draft.marts || []).map((mart) => {
      const availableSet = new Set(martColumns[mart] || []);
      const required = draft.required_columns || [];
      const missing = required.filter((column) => !availableSet.has(column));
      return {
        mart,
        required,
        available: required.filter((column) => availableSet.has(column)),
        missing,
      };
    });
  }, [draft.marts, draft.required_columns, martColumns]);

  const filteredKpis = useMemo(() => {
    const query = kpiSearch.trim().toLowerCase();
    if (!query) return kpis;
    return kpis.filter((kpi) => {
      const haystack = [
        kpi.id,
        kpi.display_name || "",
        kpi.description || "",
        kpi.pillar_id || "",
      ]
        .join(" ")
        .toLowerCase();
      return haystack.includes(query);
    });
  }, [kpiSearch, kpis]);

  const groupedKpis = useMemo(() => {
    const groups = new Map<string, StrategyKpi[]>();
    for (const kpi of filteredKpis) {
      const pillar = (kpi.pillar_id || "unassigned").trim() || "unassigned";
      if (!groups.has(pillar)) {
        groups.set(pillar, []);
      }
      groups.get(pillar)?.push(kpi);
    }
    return Array.from(groups.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  }, [filteredKpis]);

  const visibleAgentCandidates = useMemo(
    () => agentCandidates.filter((item) => !ignoredCandidateIds.includes(item.id)),
    [agentCandidates, ignoredCandidateIds]
  );
  const unresolvedSuggestionCount = useMemo(
    () => Object.keys(agentMissingById).length + (agentPatches || []).length,
    [agentMissingById, agentPatches]
  );

  const kpiStatus = useCallback(
    (kpi: StrategyKpi): "computable" | "missing_columns" | "missing_mart" | "no_target" => {
      const missingMarts = (kpi.marts || []).filter((mart) => !availableMarts.includes(mart));
      if (missingMarts.length > 0) return "missing_mart";
      for (const mart of kpi.marts || []) {
        const available = new Set(martColumns[mart] || []);
        const hasMissing = (kpi.required_columns || []).some((column) => !available.has(column));
        if (hasMissing) return "missing_columns";
      }
      if (!targetByKpiId.has(kpi.id)) {
        return "no_target";
      }
      return "computable";
    },
    [availableMarts, martColumns, targetByKpiId]
  );
  const pillarSummaryCards = useMemo(() => {
    return (pillarsDraft || []).map((pillar) => {
      const kpiCount = kpis.filter((item) => (item.pillar_id || "").trim() === pillar.id).length;
      return {
        id: pillar.id,
        description: pillar.description,
        owner: pillar.owner || "-",
        kpiCount,
      };
    });
  }, [pillarsDraft, kpis]);
  const swotSummary = useMemo(
    () => ({
      strengths: linesToList(swotText.strengths).length,
      weaknesses: linesToList(swotText.weaknesses).length,
      opportunities: linesToList(swotText.opportunities).length,
      threats: linesToList(swotText.threats).length,
    }),
    [swotText]
  );
  const targetCoverageSummary = useMemo(() => {
    const configured = targets.length;
    const total = kpis.length;
    return {
      configured,
      total,
      missing: Math.max(total - configured, 0),
    };
  }, [kpis.length, targets.length]);
  const rulesWithMeta = useMemo(() => {
    return rules.map((rule) => {
      const refs = extractRuleReferences(rule.condition);
      const unknownRefs = refs.filter((item) => !knownRuleKpis.has(item));
      return {
        ...rule,
        refs,
        unknownRefs,
        isValid: unknownRefs.length === 0,
      };
    });
  }, [knownRuleKpis, rules]);
  const validRuleCount = useMemo(
    () => rulesWithMeta.filter((item) => item.isValid).length,
    [rulesWithMeta]
  );
  const unresolvedIssueCount =
    (decision?.coverage_gaps || []).length +
    targetCoverageSummary.missing +
    (rulesWithMeta.length - validRuleCount);
  const targetRows = useMemo(() => {
    return kpis.map((kpi) => {
      const target = targetByKpiId.get(kpi.id) || null;
      const dependencyStatus = kpiStatus(kpi);
      const status =
        target != null
          ? "configured"
          : dependencyStatus === "computable"
          ? "stale"
          : "missing";
      const evaluation = evaluationByKpiId.get(kpi.id) || null;
      return {
        kpi,
        target,
        status,
        evaluationStatus: evaluation?.status || null,
      };
    });
  }, [evaluationByKpiId, kpiStatus, kpis, targetByKpiId]);
  const filteredTargetRows = useMemo(() => {
    return targetRows.filter((row) => {
      if (targetPillarFilter !== "all" && (row.kpi.pillar_id || "unassigned") !== targetPillarFilter) {
        return false;
      }
      const ownerValue = (row.target?.owner || row.kpi.owner || "").trim() || "unassigned";
      if (targetOwnerFilter !== "all" && ownerValue !== targetOwnerFilter) {
        return false;
      }
      return true;
    });
  }, [targetOwnerFilter, targetPillarFilter, targetRows]);
  const filteredRulesWithMeta = useMemo(() => {
    if (ruleSeverityFilter === "all") {
      return rulesWithMeta;
    }
    return rulesWithMeta.filter((item) => item.severity === ruleSeverityFilter);
  }, [ruleSeverityFilter, rulesWithMeta]);
  const groupedRules = useMemo(() => {
    return {
      block: filteredRulesWithMeta.filter((item) => item.severity === "block"),
      warn: filteredRulesWithMeta.filter((item) => item.severity === "warn"),
      info: filteredRulesWithMeta.filter((item) => item.severity === "info"),
    };
  }, [filteredRulesWithMeta]);
  const groupedRulesEntries = useMemo(
    () =>
      [
        ["block", groupedRules.block] as const,
        ["warn", groupedRules.warn] as const,
        ["info", groupedRules.info] as const,
      ],
    [groupedRules]
  );

  const openModal = (mode: KpiFormMode, kpi?: StrategyKpi) => {
    setFormMode(mode);
    if (!kpi) {
      setEditingId(null);
      setDraft(emptyKpi());
      setDimensionsDraft("");
      setDerivedMetricsDraft("");
    } else {
      const next = { ...kpi };
      if (mode === "duplicate") {
        next.id = `${kpi.id}_copy`;
      }
      setEditingId(mode === "edit" ? kpi.id : null);
      setDraft(next);
      setDimensionsDraft((next.dimensions || []).join(", "));
      setDerivedMetricsDraft(
        Object.entries(next.derived_metrics || {})
          .map(([name, formula]) => `${name}=${formula}`)
          .join("\n")
      );
    }
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
    setEditingId(null);
    setDraft(emptyKpi());
    setDimensionsDraft("");
    setDerivedMetricsDraft("");
  };

  const handleApiError = (requestError: unknown, fallback: string) => {
    if (requestError instanceof ApiRequestError && requestError.status === 409) {
      setError("Your strategy changed on disk. Refresh and try again.");
      return;
    }
    setError(requestError instanceof Error ? requestError.message : fallback);
  };

  const addPillarRow = () => {
    setPillarsDraft((prev) => [...prev, { id: "", description: "", owner: "" }]);
  };

  const removePillarRow = (index: number) => {
    setPillarsDraft((prev) => prev.filter((_, itemIndex) => itemIndex !== index));
  };

  const updatePillarField = (index: number, field: keyof StrategyPillarPayload, value: string) => {
    setPillarsDraft((prev) =>
      prev.map((item, itemIndex) => (itemIndex === index ? { ...item, [field]: value } : item))
    );
  };

  const saveOverview = async () => {
    const expectedRevision = overviewRevision || revision;
    if (!expectedRevision) return setError("Missing revision. Refresh and try again.");

    const pillars = pillarsDraft
      .map((item) => ({
        id: (item.id || "").trim(),
        description: (item.description || "").trim(),
        owner: (item.owner || "").trim() || null,
      }))
      .filter((item) => item.id && item.description);

    const swotPayload: StrategySwotPayload = {
      strengths: linesToList(swotText.strengths),
      weaknesses: linesToList(swotText.weaknesses),
      opportunities: linesToList(swotText.opportunities),
      threats: linesToList(swotText.threats),
    };

    const contextPayload: StrategyContextPayload = {
      company: (strategyContextDraft.company || "").trim(),
      horizon: (strategyContextDraft.horizon || "").trim(),
      north_star_metric: (strategyContextDraft.north_star_metric || "").trim(),
      narrative: (strategyContextDraft.narrative || "").trim() || null,
    };
    if (!contextPayload.company || !contextPayload.horizon || !contextPayload.north_star_metric) {
      return setError("Company, horizon, and north star metric are required.");
    }

    setSaving(true);
    setError(null);
    setSuccess(null);
    try {
      const updated = await apiClient.putStrategyOverview({
        expected_revision: expectedRevision,
        strategy_context: contextPayload,
        pillars,
        swot: swotPayload,
        author: user?.username ?? "strategy_editor",
        reason: "Update strategy overview",
      });
      setOverviewRevision(updated.revision);
      setSuccess("Overview saved.");
      await load();
    } catch (requestError) {
      handleApiError(requestError, "Failed to save strategy overview.");
    } finally {
      setSaving(false);
    }
  };

  const openTargetModal = (mode: TargetFormMode, target?: StrategyTarget, fallbackKpiId?: string) => {
    setTargetFormMode(mode);
    if (target) {
      setTargetDraft({
        kpi_id: target.kpi_id,
        target_value: Number(target.target_value ?? 0),
        red_threshold: target.red_threshold ?? null,
        yellow_threshold: target.yellow_threshold ?? null,
        direction: target.direction || "up",
        owner: target.owner || "",
        horizon: target.horizon || "",
      });
    } else {
      setTargetDraft({
        kpi_id: fallbackKpiId || "",
        target_value: 0,
        red_threshold: null,
        yellow_threshold: null,
        direction: "up",
        owner: "",
        horizon: "",
      });
    }
    setTargetModalOpen(true);
  };

  const closeTargetModal = () => {
    setTargetModalOpen(false);
    setTargetFormMode("create");
    setTargetDraft({
      kpi_id: "",
      target_value: 0,
      red_threshold: null,
      yellow_threshold: null,
      direction: "up",
      owner: "",
      horizon: "",
    });
  };

  const saveTarget = async () => {
    const expectedRevision = targetsState?.revision || revision;
    if (!expectedRevision) return setError("Missing revision. Refresh and try again.");
    if (!targetDraft.kpi_id) return setError("KPI is required.");

    const payload = {
      expected_revision: expectedRevision,
      target: {
        kpi_id: targetDraft.kpi_id,
        target_value: Number(targetDraft.target_value),
        red_threshold: targetDraft.red_threshold == null ? null : Number(targetDraft.red_threshold),
        yellow_threshold: targetDraft.yellow_threshold == null ? null : Number(targetDraft.yellow_threshold),
        direction: targetDraft.direction,
        owner: (targetDraft.owner || "").trim() || null,
        horizon: (targetDraft.horizon || "").trim() || null,
      },
      author: user?.username ?? "strategy_editor",
      reason: targetFormMode === "edit" ? `Update target ${targetDraft.kpi_id}` : `Create target ${targetDraft.kpi_id}`,
    };

    setSaving(true);
    setError(null);
    setSuccess(null);
    try {
      const updatedTargets =
        targetFormMode === "edit"
          ? await apiClient.updateStrategyTarget(targetDraft.kpi_id, payload)
          : await apiClient.createStrategyTarget(payload);
      setTargetsState(updatedTargets);
      setSuccess("Target saved.");
      closeTargetModal();
      await load();
    } catch (requestError) {
      handleApiError(requestError, "Failed to save target.");
    } finally {
      setSaving(false);
    }
  };

  const deleteTarget = async (kpiId: string) => {
    const expectedRevision = targetsState?.revision || revision;
    if (!expectedRevision) return setError("Missing revision. Refresh and try again.");
    if (!globalThis.confirm(`Delete target for '${kpiId}'?`)) return;

    setSaving(true);
    setError(null);
    setSuccess(null);
    try {
      const updatedTargets = await apiClient.deleteStrategyTarget(kpiId, {
        expected_revision: expectedRevision,
        author: user?.username ?? "strategy_editor",
        reason: `Delete target ${kpiId}`,
      });
      setTargetsState(updatedTargets);
      setSuccess("Target deleted.");
      await load();
    } catch (requestError) {
      handleApiError(requestError, "Failed to delete target.");
    } finally {
      setSaving(false);
    }
  };

  const generatedRuleCondition = `kpi("${ruleDraft.kpi_id}") ${ruleDraft.operator} ${ruleDraft.threshold || "0"}`;

  const openRuleModal = (mode: RuleFormMode, rule?: StrategyRule) => {
    setRuleFormMode(mode);
    if (!rule) {
      setRuleDraft({
        id: "",
        kpi_id: "",
        operator: "<",
        threshold: "",
        severity: "warn",
        action: "",
        rationale: "",
        ai_suggested: null,
        source: null,
      });
      setRuleModalOpen(true);
      return;
    }

    const match = rule.condition.match(/kpi\(\s*["']([^"']+)["']\s*\)\s*(<=|>=|<|>|==)\s*([0-9.+-eE]+)/);
    setRuleDraft({
      id: rule.id,
      kpi_id: match?.[1] || "",
      operator: (match?.[2] as RuleDraft["operator"]) || "<",
      threshold: match?.[3] || "",
      severity: rule.severity,
      action: rule.action,
      rationale: rule.rationale || "",
      ai_suggested: rule.ai_suggested ?? null,
      source: rule.source ?? null,
    });
    setRuleModalOpen(true);
  };

  const closeRuleModal = () => {
    setRuleModalOpen(false);
    setRuleFormMode("create");
    setRuleDraft({
      id: "",
      kpi_id: "",
      operator: "<",
      threshold: "",
      severity: "warn",
      action: "",
      rationale: "",
      ai_suggested: null,
      source: null,
    });
  };

  const saveRule = async () => {
    const expectedRevision = rulesState?.revision || revision;
    if (!expectedRevision) return setError("Missing revision. Refresh and try again.");
    if (!ruleDraft.id.trim()) return setError("Rule id is required.");
    if (!ruleDraft.kpi_id.trim()) return setError("KPI is required.");
    if (!ruleDraft.threshold.trim()) return setError("Threshold is required.");
    if (!ruleDraft.action.trim()) return setError("Action is required.");

    const payload = {
      expected_revision: expectedRevision,
      rule: {
        id: ruleDraft.id.trim(),
        condition: generatedRuleCondition,
        action: ruleDraft.action.trim(),
        severity: ruleDraft.severity,
        rationale: ruleDraft.rationale.trim() || null,
        ai_suggested: ruleDraft.ai_suggested ?? null,
        source: ruleDraft.source ?? null,
      },
      author: user?.username ?? "strategy_editor",
      reason: ruleFormMode === "edit" ? `Update rule ${ruleDraft.id.trim()}` : `Create rule ${ruleDraft.id.trim()}`,
    };

    setSaving(true);
    setError(null);
    setSuccess(null);
    try {
      const updatedRules =
        ruleFormMode === "edit"
          ? await apiClient.updateStrategyRule(ruleDraft.id.trim(), payload)
          : await apiClient.createStrategyRule(payload);
      setRulesState(updatedRules);
      setSuccess("Rule saved.");
      closeRuleModal();
      await load();
    } catch (requestError) {
      handleApiError(requestError, "Failed to save rule.");
    } finally {
      setSaving(false);
    }
  };

  const deleteRule = async (ruleId: string) => {
    const expectedRevision = rulesState?.revision || revision;
    if (!expectedRevision) return setError("Missing revision. Refresh and try again.");
    if (!globalThis.confirm(`Delete rule '${ruleId}'?`)) return;

    setSaving(true);
    setError(null);
    setSuccess(null);
    try {
      const updatedRules = await apiClient.deleteStrategyRule(ruleId, {
        expected_revision: expectedRevision,
        author: user?.username ?? "strategy_editor",
        reason: `Delete rule ${ruleId}`,
      });
      setRulesState(updatedRules);
      setSuccess("Rule deleted.");
      await load();
    } catch (requestError) {
      handleApiError(requestError, "Failed to delete rule.");
    } finally {
      setSaving(false);
    }
  };

  const saveKpi = async () => {
    if (!revision) return setError("Missing revision. Refresh and try again.");
    const derivedMetrics = Object.fromEntries(
      derivedMetricsDraft
        .split("\n")
        .map((line) => line.trim())
        .filter(Boolean)
        .map((line) => {
          const [left, ...right] = line.includes("=") ? line.split("=") : line.split(":");
          return [left?.trim() || "", right.join("=").trim()];
        })
        .filter(([name, formula]) => Boolean(name) && Boolean(formula))
    );
    const normalized = normalizeKpi({
      ...draft,
      dimensions: dimensionsDraft.split(",").map((v) => v.trim()).filter(Boolean),
      derived_metrics: derivedMetrics,
    });
    if (!normalized.id || !normalized.description || !normalized.formula || normalized.marts.length === 0) {
      return setError("ID, description, formula, and at least one mart are required.");
    }
    setSaving(true);
    setError(null);
    setSuccess(null);
    try {
      const payload = {
        expected_revision: revision,
        dataset_id: datasetId,
        kpi: normalized,
        author: user?.username ?? "strategy_editor",
        reason: formMode === "edit" ? `Update ${normalized.id}` : `Create ${normalized.id}`,
      };
      if (formMode === "edit" && editingId) {
        await apiClient.updateStrategyKpi(editingId, payload);
      } else {
        await apiClient.createStrategyKpi(payload);
      }
      closeModal();
      setSuccess("KPI saved.");
      await load();
    } catch (requestError) {
      handleApiError(requestError, "Failed to save KPI.");
    } finally {
      setSaving(false);
    }
  };

  const deleteKpi = async (kpiId: string) => {
    if (!revision) return setError("Missing revision. Refresh and try again.");
    if (!globalThis.confirm(`Delete KPI '${kpiId}'?`)) return;
    setSaving(true);
    setError(null);
    setSuccess(null);
    try {
      await apiClient.deleteStrategyKpi(kpiId, {
        expected_revision: revision,
        dataset_id: datasetId,
        author: user?.username ?? "strategy_editor",
        reason: `Delete ${kpiId}`,
      });
      setSuccess("KPI deleted.");
      await load();
    } catch (requestError) {
      handleApiError(requestError, "Failed to delete KPI.");
    } finally {
      setSaving(false);
    }
  };

  const saveYaml = async () => {
    if (!revision) return setError("Missing revision. Refresh and try again.");
    setSaving(true);
    setError(null);
    setSuccess(null);
    setYamlValidationMessage(null);
    try {
      if (editor === "strategy") {
        await apiClient.putStrategyBundle({
          expected_revision: revision,
          mode: strategyMode,
          yaml: strategyText,
          author: user?.username ?? "strategy_editor",
          reason: "Update strategy YAML",
        });
      } else {
        await apiClient.putKpiRegistryBundle({
          expected_revision: revision,
          mode: kpiMode,
          yaml: kpiText,
          author: user?.username ?? "strategy_editor",
          reason: "Update KPI YAML",
        });
      }
      setSuccess("Saved.");
      setYamlValidationMessage(`Saved ${editor === "strategy" ? "strategy bundle" : "KPI registry"} YAML at revision ${revision}.`);
      await load();
    } catch (requestError) {
      if (requestError instanceof ApiRequestError && requestError.code) {
        const hint = requestError.hint ? ` ${requestError.hint}` : "";
        setYamlValidationMessage(`${requestError.code}: ${requestError.message}.${hint}`.trim());
      } else {
        setYamlValidationMessage("YAML save failed. Resolve validation issues and try again.");
      }
      handleApiError(requestError, "Failed to save YAML.");
    } finally {
      setSaving(false);
    }
  };

  const refreshYamlEditors = async () => {
    setError(null);
    setSuccess(null);
    setYamlValidationMessage(null);
    await load();
    setSuccess("Refreshed YAML editors from latest revision.");
  };

  const suggestKpis = async () => {
    if (!revision) {
      setError("Missing revision. Refresh and try again.");
      return;
    }
    if (!strategyNotes.trim()) {
      setError("Add strategy notes before requesting KPI suggestions.");
      return;
    }

    setAgentLoading(true);
    setError(null);
    setSuccess(null);
    try {
      const extracted = await apiClient.extractStrategyKpis({
        dataset_id: datasetId,
        text: strategyNotes,
        expected_revision: revision,
      });
      setAgentCandidates(extracted.candidates || []);
      const extractedNotes = [...(extracted.notes || [])];
      if (extracted.alias_suggestions && Object.keys(extracted.alias_suggestions).length > 0) {
        extractedNotes.push(
          `Alias suggestions: ${Object.entries(extracted.alias_suggestions)
            .map(([key, value]) => `${key} -> ${value}`)
            .join(", ")}`
        );
      }
      if (extracted.derived_metric_suggestions && Object.keys(extracted.derived_metric_suggestions).length > 0) {
        extractedNotes.push(
          `Derived metric suggestions: ${Object.entries(extracted.derived_metric_suggestions)
            .map(([key, value]) => `${key}=${value}`)
            .join("; ")}`
        );
      }
      setAgentNotes(extractedNotes);

      if ((extracted.candidates || []).length > 0) {
        const reconciled = await apiClient.reconcileStrategyKpis({
          dataset_id: datasetId,
          candidates: extracted.candidates || [],
          expected_revision: extracted.revision,
        });
        setAgentCandidates((reconciled.candidates || extracted.candidates || []) as StrategyKpi[]);
        const nextMissing: Record<string, string> = {};
        for (const item of reconciled.missing_dependencies || reconciled.missing || []) {
          nextMissing[item.kpi_id] = missingSummary(item);
        }
        setAgentMissingById(nextMissing);
        const nextMatches: Record<string, string[]> = {};
        for (const item of reconciled.column_matches || []) {
          const rendered = `${item.missing_column} -> ${item.suggested_columns.join(", ")}`;
          if (!nextMatches[item.kpi_id]) {
            nextMatches[item.kpi_id] = [];
          }
          nextMatches[item.kpi_id].push(rendered);
        }
        setAgentColumnMatchesById(nextMatches);
        const nextPatches = reconciled.patches || [];
        setAgentPatches(nextPatches);
        setSelectedPatchIds(
          nextPatches
            .filter((item) => (item.confidence || 0) >= 0.65)
            .map((item) => item.patch_id)
        );
        setIgnoredCandidateIds([]);
      } else {
        setAgentMissingById({});
        setAgentColumnMatchesById({});
        setAgentPatches([]);
        setSelectedPatchIds([]);
        setIgnoredCandidateIds([]);
      }

      setSuccess(`Suggested ${(extracted.candidates || []).length} KPI(s).`);
    } catch (requestError) {
      handleApiError(requestError, "Failed to generate KPI suggestions.");
    } finally {
      setAgentLoading(false);
    }
  };

  const addSuggestedKpi = async (candidate: StrategyKpi) => {
    if (!revision) {
      setError("Missing revision. Refresh and try again.");
      return;
    }
    const normalized = normalizeKpi(candidate);
    setAddingCandidateId(normalized.id);
    setError(null);
    setSuccess(null);
    try {
      await apiClient.createStrategyKpi({
        expected_revision: revision,
        dataset_id: datasetId,
        kpi: normalized,
        author: user?.username ?? "strategy_editor",
        reason: `Add suggested KPI ${normalized.id}`,
      });
      setSuccess(`Added KPI '${normalized.id}'.`);
      setAgentCandidates((prev) => prev.filter((item) => item.id !== normalized.id));
      setAgentMissingById((prev) => {
        const next = { ...prev };
        delete next[normalized.id];
        return next;
      });
      setAgentColumnMatchesById((prev) => {
        const next = { ...prev };
        delete next[normalized.id];
        return next;
      });
      await load();
    } catch (requestError) {
      handleApiError(requestError, "Failed to add suggested KPI.");
    } finally {
      setAddingCandidateId(null);
    }
  };

  const ignoreSuggestedKpi = (kpiId: string) => {
    setIgnoredCandidateIds((prev) => (prev.includes(kpiId) ? prev : [...prev, kpiId]));
  };

  const applySelectedAgentPatches = async (patchIds: string[]) => {
    if (!revision) {
      setError("Missing revision. Refresh and try again.");
      return;
    }
    if (patchIds.length === 0) {
      setError("Select at least one patch to apply.");
      return;
    }
    setAgentApplying(true);
    setError(null);
    setSuccess(null);
    try {
      const response = await apiClient.applyStrategyPatches({
        dataset_id: datasetId,
        expected_revision: revision,
        selected_patch_ids: patchIds,
        patches: agentPatches,
        author: user?.username ?? "strategy_editor",
        reason: "Apply selected reconciliation patches",
      });
      setLastApplyBaseRevision(response.previous_revision || revision);
      setSuccess(`Applied ${response.applied_summary.applied_count} patch(es).`);
      setAgentPatches((prev) => prev.filter((item) => !patchIds.includes(item.patch_id)));
      setSelectedPatchIds([]);
      await load();
    } catch (requestError) {
      handleApiError(requestError, "Failed to apply selected patches.");
    } finally {
      setAgentApplying(false);
    }
  };

  const applyAllSafeAgentPatches = async () => {
    const safeIds = agentPatches.filter((item) => (item.confidence || 0) >= 0.7).map((item) => item.patch_id);
    await applySelectedAgentPatches(safeIds);
  };

  const undoLastPatchApply = async () => {
    if (!revision) {
      setError("Missing revision. Refresh and try again.");
      return;
    }
    if (!lastApplyBaseRevision) {
      setError("No patch application to undo in this session.");
      return;
    }
    setAgentUndoing(true);
    setError(null);
    setSuccess(null);
    try {
      const response = await apiClient.undoStrategyPatches({
        dataset_id: datasetId,
        revision_to_restore: lastApplyBaseRevision,
        expected_revision: revision,
        author: user?.username ?? "strategy_editor",
        reason: "Undo last patch apply",
      });
      setSuccess(`Restored strategy artifacts from ${response.restored_from_revision}.`);
      setLastApplyBaseRevision(null);
      await load();
    } catch (requestError) {
      handleApiError(requestError, "Failed to undo patch apply.");
    } finally {
      setAgentUndoing(false);
    }
  };

  const runEvaluation = async () => {
    setEvaluationLoading(true);
    setError(null);
    setSuccess(null);
    try {
      const [evaluated, signals] = await Promise.all([
        apiClient.evaluateStrategy({
          dataset_id: datasetId,
          filters: [],
          time_range: null,
        }),
        apiClient.getStrategyDecisionSignals(datasetId),
      ]);
      setEvaluationState(evaluated);
      setDecisionSignalsState(signals);
      setSuccess("Strategy evaluation completed.");
    } catch (requestError) {
      handleApiError(requestError, "Failed to evaluate strategy.");
    } finally {
      setEvaluationLoading(false);
    }
  };

  return (
    <div className="h-full overflow-y-auto p-4 space-y-4 bg-gradient-to-br from-white via-indigo-50/20 to-violet-50/20">
      <div className="rounded-xl border border-indigo-200/60 bg-white p-4 shadow-sm flex items-center justify-between">
        <div>
          <h2 className="font-semibold text-slate-900">Strategy</h2>
          <p className="text-xs text-slate-600">
            Dataset: {datasetId} | Revision: {revision ?? "n/a"} | Readiness: {readiness ? scoreText(readiness.overall_score) : "n/a"}
          </p>
        </div>
        <button type="button" onClick={() => void load()} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50">
          <RefreshCw className="h-3.5 w-3.5" />
          Refresh
        </button>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-3 flex flex-wrap gap-2">
        {sections.map((item) => (
          <button key={item.id} type="button" onClick={() => setSection(item.id)} className={`rounded-lg px-3 py-1.5 text-xs border ${section === item.id ? "border-indigo-300 bg-indigo-100 text-indigo-700" : "border-slate-300 bg-white text-slate-700"}`}>{item.label}</button>
        ))}
      </div>

      <div className="rounded-xl border border-indigo-200 bg-indigo-50/60 px-3 py-2">
        <p className="text-xs font-semibold uppercase tracking-wide text-indigo-700">{sectionGuidance[section].title}</p>
        <p className="mt-1 text-xs text-slate-700">{sectionGuidance[section].body}</p>
      </div>

      {loading ? <div className="rounded-xl border border-slate-200 bg-white p-4 text-sm text-slate-600">Loading...</div> : null}
      {error ? <div className="rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700"><div className="flex items-center gap-2"><AlertTriangle className="h-4 w-4" /><span>{error}</span></div></div> : null}
      {success ? <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-700">{success}</div> : null}

      {section === "overview" ? (
        <div className="space-y-3">
          <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
            <div className="grid grid-cols-1 gap-3 lg:grid-cols-4">
              <div className="rounded-lg border border-indigo-200 bg-indigo-50 p-3 lg:col-span-2">
                <p className="text-xs font-semibold text-indigo-700">Strategy Summary</p>
                <p className="mt-1 text-sm text-slate-700">
                  {strategyContextDraft.narrative?.trim()
                    ? `${strategyContextDraft.narrative.trim().slice(0, 220)}${strategyContextDraft.narrative.trim().length > 220 ? "..." : ""}`
                    : "Add a strategy narrative to align teams on growth, retention, margin, and inventory priorities."}
                </p>
              </div>
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                <p className="text-xs font-semibold text-slate-700">Target Coverage</p>
                <p className="mt-1 text-lg font-semibold text-slate-900">
                  {targetCoverageSummary.configured}/{targetCoverageSummary.total}
                </p>
                <p className="text-[11px] text-slate-600">{targetCoverageSummary.missing} KPI(s) without targets</p>
              </div>
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                <p className="text-xs font-semibold text-slate-700">Rule Coverage</p>
                <p className="mt-1 text-lg font-semibold text-slate-900">
                  {validRuleCount}/{rulesWithMeta.length}
                </p>
                <p className="text-[11px] text-slate-600">{rulesWithMeta.length - validRuleCount} invalid rule(s)</p>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-3 md:grid-cols-4">
              <div className="rounded-lg border border-slate-200 bg-white p-3">
                <p className="text-xs text-slate-500">Strengths</p>
                <p className="text-lg font-semibold text-slate-800">{swotSummary.strengths}</p>
              </div>
              <div className="rounded-lg border border-slate-200 bg-white p-3">
                <p className="text-xs text-slate-500">Weaknesses</p>
                <p className="text-lg font-semibold text-slate-800">{swotSummary.weaknesses}</p>
              </div>
              <div className="rounded-lg border border-slate-200 bg-white p-3">
                <p className="text-xs text-slate-500">Opportunities</p>
                <p className="text-lg font-semibold text-slate-800">{swotSummary.opportunities}</p>
              </div>
              <div className="rounded-lg border border-slate-200 bg-white p-3">
                <p className="text-xs text-slate-500">Threats</p>
                <p className="text-lg font-semibold text-slate-800">{swotSummary.threats}</p>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
              {pillarSummaryCards.map((pillar) => (
                <div key={`pillar-summary-${pillar.id}`} className="rounded-lg border border-slate-200 bg-white p-3">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-xs font-semibold uppercase tracking-wide text-slate-700">{pillar.id}</p>
                    <span className="rounded-full bg-indigo-100 px-2 py-0.5 text-[10px] text-indigo-700">
                      {pillar.kpiCount} KPI(s)
                    </span>
                  </div>
                  <p className="mt-1 text-[11px] text-slate-600">{pillar.description}</p>
                  <p className="mt-1 text-[11px] text-slate-500">Owner: {pillar.owner}</p>
                </div>
              ))}
              {pillarSummaryCards.length === 0 ? (
                <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs text-slate-600 md:col-span-2 xl:col-span-4">
                  No pillars configured yet.
                </div>
              ) : null}
            </div>
            <div className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
              Unresolved issues: {unresolvedIssueCount}
            </div>
          </div>
          <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900">Strategy Overview</h3>
              <button
                type="button"
                onClick={() => void saveOverview()}
                disabled={saving}
                className="inline-flex items-center gap-1 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs text-white hover:bg-indigo-700 disabled:opacity-60"
              >
                <Save className="h-3.5 w-3.5" />
                Save Overview
              </button>
            </div>
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              <input
                value={strategyContextDraft.company}
                onChange={(event) => setStrategyContextDraft((prev) => ({ ...prev, company: event.target.value }))}
                placeholder="Company"
                className="rounded border border-slate-300 px-2 py-1.5 text-xs"
              />
              <input
                value={strategyContextDraft.horizon}
                onChange={(event) => setStrategyContextDraft((prev) => ({ ...prev, horizon: event.target.value }))}
                placeholder="Horizon"
                className="rounded border border-slate-300 px-2 py-1.5 text-xs"
              />
              <input
                value={strategyContextDraft.north_star_metric}
                onChange={(event) => setStrategyContextDraft((prev) => ({ ...prev, north_star_metric: event.target.value }))}
                placeholder="North Star Metric"
                className="rounded border border-slate-300 px-2 py-1.5 text-xs md:col-span-2"
              />
              <textarea
                value={strategyContextDraft.narrative || ""}
                onChange={(event) => setStrategyContextDraft((prev) => ({ ...prev, narrative: event.target.value }))}
                placeholder="Narrative"
                className="h-20 rounded border border-slate-300 px-2 py-1.5 text-xs md:col-span-2"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-semibold text-slate-700">Pillars</h4>
                <button
                  type="button"
                  onClick={addPillarRow}
                  className="inline-flex items-center gap-1 rounded border border-slate-300 px-2 py-1 text-[11px] text-slate-700 hover:bg-slate-50"
                >
                  <Plus className="h-3 w-3" />
                  Add Pillar
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500">
                      <th className="px-2 py-2">ID</th>
                      <th className="px-2 py-2">Description</th>
                      <th className="px-2 py-2">Owner</th>
                      <th className="px-2 py-2">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pillarsDraft.map((pillar, index) => (
                      <tr key={`${pillar.id || "pillar"}-${index}`} className="border-b border-slate-100">
                        <td className="px-2 py-2">
                          <input
                            value={pillar.id}
                            onChange={(event) => updatePillarField(index, "id", event.target.value)}
                            className="w-full rounded border border-slate-300 px-2 py-1 text-xs"
                          />
                        </td>
                        <td className="px-2 py-2">
                          <input
                            value={pillar.description}
                            onChange={(event) => updatePillarField(index, "description", event.target.value)}
                            className="w-full rounded border border-slate-300 px-2 py-1 text-xs"
                          />
                        </td>
                        <td className="px-2 py-2">
                          <input
                            value={pillar.owner || ""}
                            onChange={(event) => updatePillarField(index, "owner", event.target.value)}
                            className="w-full rounded border border-slate-300 px-2 py-1 text-xs"
                          />
                        </td>
                        <td className="px-2 py-2">
                          <button
                            type="button"
                            onClick={() => removePillarRow(index)}
                            className="inline-flex items-center gap-1 rounded border border-red-300 px-2 py-1 text-[11px] text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="h-3 w-3" />
                            Remove
                          </button>
                        </td>
                      </tr>
                    ))}
                    {pillarsDraft.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="px-2 py-3 text-center text-slate-500">
                          No pillars configured.
                        </td>
                      </tr>
                    ) : null}
                  </tbody>
                </table>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              <textarea value={swotText.strengths} onChange={(event) => setSwotText((prev) => ({ ...prev, strengths: event.target.value }))} placeholder="Strengths (one per line)" className="h-24 rounded border border-slate-300 px-2 py-1.5 text-xs" />
              <textarea value={swotText.weaknesses} onChange={(event) => setSwotText((prev) => ({ ...prev, weaknesses: event.target.value }))} placeholder="Weaknesses (one per line)" className="h-24 rounded border border-slate-300 px-2 py-1.5 text-xs" />
              <textarea value={swotText.opportunities} onChange={(event) => setSwotText((prev) => ({ ...prev, opportunities: event.target.value }))} placeholder="Opportunities (one per line)" className="h-24 rounded border border-slate-300 px-2 py-1.5 text-xs" />
              <textarea value={swotText.threats} onChange={(event) => setSwotText((prev) => ({ ...prev, threats: event.target.value }))} placeholder="Threats (one per line)" className="h-24 rounded border border-slate-300 px-2 py-1.5 text-xs" />
            </div>
          </div>
          {readiness ? (
            <>
              {!kpisDefined ? <div className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-800">No KPIs defined yet. Add KPIs to enable coverage and readiness.</div> : null}
              {kpisDefined && !targetsDefined ? <div className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-800">Targets are missing. Configure targets to improve readiness.</div> : null}
              {kpisDefined && !rulesDefined ? <div className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-800">Rules are missing. Add strategy rules to improve readiness.</div> : null}
              <div className="grid grid-cols-1 gap-3 md:grid-cols-6">
                <div className="rounded-xl border border-indigo-200 bg-white p-3"><p className="text-xs text-slate-500">Overall</p><p className="text-lg font-semibold text-indigo-700">{scoreText(readiness.overall_score)}</p></div>
                <div className="rounded-xl border border-indigo-200 bg-white p-3"><p className="text-xs text-slate-500">Strategy</p><p className="text-lg font-semibold text-indigo-700">{scoreText(readiness.strategy_completeness)}</p></div>
                <div className="rounded-xl border border-indigo-200 bg-white p-3"><p className="text-xs text-slate-500">KPI</p><p className="text-lg font-semibold text-indigo-700">{scoreText(readiness.kpi_completeness)}</p></div>
                <div className="rounded-xl border border-indigo-200 bg-white p-3"><p className="text-xs text-slate-500">Targets</p><p className="text-lg font-semibold text-indigo-700">{scoreText(readiness.target_completeness)}</p></div>
                <div className="rounded-xl border border-indigo-200 bg-white p-3"><p className="text-xs text-slate-500">Rules</p><p className="text-lg font-semibold text-indigo-700">{scoreText(readiness.rule_completeness)}</p></div>
                <div className="rounded-xl border border-indigo-200 bg-white p-3"><p className="text-xs text-slate-500">Data Readiness</p><p className="text-lg font-semibold text-indigo-700">{kpisDefined ? scoreText(readiness.data_readiness) : "-"}</p></div>
                <div className="rounded-xl border border-indigo-200 bg-white p-3"><p className="text-xs text-slate-500">Reconciliation</p><p className="text-lg font-semibold text-indigo-700">{scoreText(readiness.reconciliation_completeness)}</p></div>
              </div>
              {(decision?.readiness_notes || []).length > 0 ? (
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
                  <p className="text-xs font-semibold text-slate-700">Readiness Notes</p>
                  <ul className="mt-1 list-disc space-y-1 pl-4 text-xs text-slate-600">
                    {(decision?.readiness_notes || []).map((note) => (
                      <li key={`overview-readiness-${note}`}>{note}</li>
                    ))}
                  </ul>
                </div>
              ) : null}
              <div className="rounded-xl border border-slate-200 bg-white p-4">
                <h3 className="text-sm font-semibold text-slate-900">Coverage Gaps</h3>
                {(decision?.coverage_gaps || []).length === 0 ? <p className="mt-2 text-sm text-slate-600">No coverage gaps detected.</p> : (
                  <div className="mt-2 overflow-x-auto"><table className="min-w-full text-left text-xs"><thead><tr className="border-b border-slate-200 text-slate-500"><th className="px-2 py-2">KPI</th><th className="px-2 py-2">Reason</th><th className="px-2 py-2">Details</th></tr></thead><tbody>{(decision?.coverage_gaps || []).map((gap) => <tr key={`${gap.kpi_id}-${gap.reason}`} className="border-b border-slate-100"><td className="px-2 py-2 font-medium">{gap.kpi_id}</td><td className="px-2 py-2">{gap.reason}</td><td className="px-2 py-2">{gapSummary(gap)}</td></tr>)}</tbody></table></div>
                )}
              </div>
            </>
          ) : null}
        </div>
      ) : null}

      {section === "kpi_library" ? (
        <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-sm font-semibold text-slate-900">KPI Library</h3>
            <div className="flex items-center gap-2">
              <input
                value={kpiSearch}
                onChange={(event) => setKpiSearch(event.target.value)}
                placeholder="Search KPIs..."
                className="rounded border border-slate-300 px-2 py-1.5 text-xs"
              />
              <button
                type="button"
                onClick={() => openModal("create")}
                className="inline-flex items-center gap-1 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs text-white hover:bg-indigo-700"
              >
                <Plus className="h-3.5 w-3.5" />
                Add KPI
              </button>
            </div>
          </div>
          {groupedKpis.map(([pillar, items]) => (
            <div key={`pillar-${pillar}`} className="space-y-2">
              <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-600">{pillar}</h4>
              <div className="overflow-x-auto">
                <table className="min-w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500">
                      <th className="px-2 py-2">ID</th>
                      <th className="px-2 py-2">Name</th>
                      <th className="px-2 py-2">Marts</th>
                      <th className="px-2 py-2">Status</th>
                      <th className="px-2 py-2">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((kpi) => {
                      const status = kpiStatus(kpi);
                      const statusLabel =
                        status === "computable"
                          ? "computable"
                          : status === "missing_columns"
                          ? "missing columns"
                          : status === "missing_mart"
                          ? "missing mart"
                          : "no target";
                      const statusClass =
                        status === "computable"
                          ? "bg-emerald-100 text-emerald-700"
                          : status === "no_target"
                          ? "bg-amber-100 text-amber-700"
                          : "bg-red-100 text-red-700";
                      return (
                        <tr key={kpi.id} className="border-b border-slate-100">
                          <td className="px-2 py-2 font-medium">{kpi.id}</td>
                          <td className="px-2 py-2">{kpi.display_name || kpi.description}</td>
                          <td className="px-2 py-2">{(kpi.marts || []).join(", ") || "-"}</td>
                          <td className="px-2 py-2">
                            <span className={`rounded-full px-2 py-0.5 text-[10px] ${statusClass}`}>{statusLabel}</span>
                          </td>
                          <td className="px-2 py-2">
                            <div className="flex flex-wrap gap-1">
                              <button type="button" onClick={() => openInAnalytics(kpi)} className="inline-flex items-center gap-1 rounded border border-indigo-300 px-2 py-0.5 text-[10px] text-indigo-700 hover:bg-indigo-50"><BarChart3 className="h-3 w-3" />Inspect</button>
                              <button type="button" onClick={() => openModal("edit", kpi)} className="rounded border border-slate-300 px-2 py-0.5 text-[10px] hover:bg-slate-100">Edit</button>
                              <button type="button" onClick={() => openModal("duplicate", kpi)} className="rounded border border-slate-300 px-2 py-0.5 text-[10px] hover:bg-slate-100">Duplicate</button>
                              <button type="button" onClick={() => void deleteKpi(kpi.id)} className="inline-flex items-center gap-1 rounded border border-red-300 px-2 py-0.5 text-[10px] text-red-700 hover:bg-red-50"><Trash2 className="h-3 w-3" />Delete</button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
          {groupedKpis.length === 0 ? <div className="rounded border border-slate-200 px-3 py-4 text-center text-xs text-slate-500">No KPIs match the current filter.</div> : null}
        </div>
      ) : null}

      {section === "targets" ? (
        <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="text-sm font-semibold text-slate-900">Targets</h3>
            <div className="flex items-center gap-2">
              <select
                value={targetPillarFilter}
                onChange={(event) => setTargetPillarFilter(event.target.value)}
                className="rounded border border-slate-300 px-2 py-1.5 text-xs"
              >
                <option value="all">All pillars</option>
                <option value="unassigned">Unassigned</option>
                {targetFilterPillars.map((pillar) => (
                  <option key={`target-filter-pillar-${pillar}`} value={pillar}>
                    {pillar}
                  </option>
                ))}
              </select>
              <select
                value={targetOwnerFilter}
                onChange={(event) => setTargetOwnerFilter(event.target.value)}
                className="rounded border border-slate-300 px-2 py-1.5 text-xs"
              >
                <option value="all">All owners</option>
                <option value="unassigned">Unassigned</option>
                {targetFilterOwners.map((owner) => (
                  <option key={`target-filter-owner-${owner}`} value={owner}>
                    {owner}
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={() => openTargetModal("create")}
                className="inline-flex items-center gap-1 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs text-white hover:bg-indigo-700"
              >
                <Plus className="h-3.5 w-3.5" />
                Add Target
              </button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500">
                  <th className="px-2 py-2">KPI</th>
                  <th className="px-2 py-2">Target</th>
                  <th className="px-2 py-2">Yellow</th>
                  <th className="px-2 py-2">Red</th>
                  <th className="px-2 py-2">Direction</th>
                  <th className="px-2 py-2">Owner</th>
                  <th className="px-2 py-2">Horizon</th>
                  <th className="px-2 py-2">Status</th>
                  <th className="px-2 py-2">Linked KPI Status</th>
                  <th className="px-2 py-2">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredTargetRows.map((row) => {
                  const kpi = row.kpi;
                  const target = row.target;
                  const status = row.status;
                  const statusClass =
                    status === "configured"
                      ? "bg-emerald-100 text-emerald-700"
                      : status === "stale"
                      ? "bg-amber-100 text-amber-700"
                      : "bg-slate-100 text-slate-700";
                  const linkedStatus = row.evaluationStatus;
                  const linkedClass =
                    linkedStatus === "green"
                      ? "bg-emerald-100 text-emerald-700"
                      : linkedStatus === "yellow" || linkedStatus === "no_target"
                      ? "bg-amber-100 text-amber-700"
                      : linkedStatus === "red" || linkedStatus === "unavailable"
                      ? "bg-red-100 text-red-700"
                      : "bg-slate-100 text-slate-700";
                  return (
                    <tr key={`target-${kpi.id}`} className="border-b border-slate-100">
                      <td className="px-2 py-2 font-medium">{kpi.id}</td>
                      <td className="px-2 py-2">{target ? target.target_value : "-"}</td>
                      <td className="px-2 py-2">{target?.yellow_threshold ?? "-"}</td>
                      <td className="px-2 py-2">{target?.red_threshold ?? "-"}</td>
                      <td className="px-2 py-2">{target?.direction ?? "-"}</td>
                      <td className="px-2 py-2">{target?.owner || "-"}</td>
                      <td className="px-2 py-2">{target?.horizon || "-"}</td>
                      <td className="px-2 py-2">
                        <span className={`rounded-full px-2 py-0.5 text-[10px] ${statusClass}`}>
                          {status}
                        </span>
                      </td>
                      <td className="px-2 py-2">
                        <span className={`rounded-full px-2 py-0.5 text-[10px] ${linkedClass}`}>
                          {linkedStatus || "n/a"}
                        </span>
                      </td>
                      <td className="px-2 py-2">
                        <div className="flex flex-wrap gap-1">
                          {target ? (
                            <>
                              <button
                                type="button"
                                onClick={() => openTargetModal("edit", target)}
                                className="rounded border border-slate-300 px-2 py-0.5 text-[10px] hover:bg-slate-100"
                              >
                                Edit
                              </button>
                              <button
                                type="button"
                                onClick={() => void deleteTarget(kpi.id)}
                                className="inline-flex items-center gap-1 rounded border border-red-300 px-2 py-0.5 text-[10px] text-red-700 hover:bg-red-50"
                              >
                                <Trash2 className="h-3 w-3" />
                                Delete
                              </button>
                            </>
                          ) : (
                            <button
                              type="button"
                              onClick={() => openTargetModal("create", undefined, kpi.id)}
                              className="rounded border border-indigo-300 px-2 py-0.5 text-[10px] text-indigo-700 hover:bg-indigo-50"
                            >
                              Configure
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
                {filteredTargetRows.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="px-2 py-4 text-center text-slate-500">
                      No KPIs match current filters.
                    </td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          </div>
        </div>
      ) : null}
      {section === "rules" ? (
        <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="text-sm font-semibold text-slate-900">Rules</h3>
            <div className="flex items-center gap-2">
              <select
                value={ruleSeverityFilter}
                onChange={(event) =>
                  setRuleSeverityFilter(event.target.value as "all" | "block" | "warn" | "info")
                }
                className="rounded border border-slate-300 px-2 py-1.5 text-xs"
              >
                <option value="all">All severities</option>
                <option value="block">Critical (block)</option>
                <option value="warn">Warn</option>
                <option value="info">Info</option>
              </select>
              <button
                type="button"
                onClick={() => openRuleModal("create")}
                className="inline-flex items-center gap-1 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs text-white hover:bg-indigo-700"
              >
                <Plus className="h-3.5 w-3.5" />
                Add Rule
              </button>
            </div>
          </div>
          {groupedRulesEntries.map(([severity, severityRules]) => (
            <div key={`rules-${severity}`} className="space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-600">
                  {severity} ({severityRules.length})
                </p>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500">
                      <th className="px-2 py-2">ID</th>
                      <th className="px-2 py-2">Condition</th>
                      <th className="px-2 py-2">Affected KPIs</th>
                      <th className="px-2 py-2">Action</th>
                      <th className="px-2 py-2">Status</th>
                      <th className="px-2 py-2">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {severityRules.map((rule) => (
                      <tr key={rule.id} className="border-b border-slate-100">
                        <td className="px-2 py-2 font-medium">
                          <div className="flex flex-wrap items-center gap-1">
                            <span>{rule.id}</span>
                            {rule.ai_suggested || rule.source === "agent" ? (
                              <span className="rounded-full bg-violet-100 px-2 py-0.5 text-[10px] text-violet-700">
                                AI suggested
                              </span>
                            ) : null}
                          </div>
                        </td>
                        <td className="px-2 py-2 font-mono text-[11px]">{rule.condition}</td>
                        <td className="px-2 py-2">{rule.refs.length > 0 ? rule.refs.join(", ") : "-"}</td>
                        <td className="px-2 py-2">{rule.action}</td>
                        <td className="px-2 py-2">
                          <span
                            className={`rounded-full px-2 py-0.5 text-[10px] ${
                              rule.isValid ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"
                            }`}
                          >
                            {rule.isValid ? "valid" : `invalid refs: ${rule.unknownRefs.join(", ")}`}
                          </span>
                        </td>
                        <td className="px-2 py-2">
                          <div className="flex flex-wrap gap-1">
                            <button
                              type="button"
                              onClick={() => openRuleModal("edit", rule)}
                              className="rounded border border-slate-300 px-2 py-0.5 text-[10px] hover:bg-slate-100"
                            >
                              Edit
                            </button>
                            <button
                              type="button"
                              onClick={() => void deleteRule(rule.id)}
                              className="inline-flex items-center gap-1 rounded border border-red-300 px-2 py-0.5 text-[10px] text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-3 w-3" />
                              Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {severityRules.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-2 py-4 text-center text-slate-500">
                          No rules in this severity group.
                        </td>
                      </tr>
                    ) : null}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
          {filteredRulesWithMeta.length === 0 ? (
            <div className="rounded border border-slate-200 px-3 py-4 text-center text-xs text-slate-500">
              No rules match current filters.
            </div>
          ) : null}
        </div>
      ) : null}
      {section === "reconciliation" ? (
        <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">Reconciliation</h3>
            <p className="text-xs text-slate-600">
              Patch Center workflow: extract suggestions, review dependency fixes, apply selected patches, and undo if needed.
            </p>
          </div>
          <div className="grid grid-cols-1 gap-3 xl:grid-cols-3">
            <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 space-y-2">
              <p className="text-xs font-semibold text-slate-700">Strategy Notes</p>
              <textarea
                value={strategyNotes}
                onChange={(event) => setStrategyNotes(event.target.value)}
                placeholder="Paste strategy notes..."
                className="h-32 w-full rounded-lg border border-slate-300 bg-white p-3 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-400"
              />
              <div className="flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => void suggestKpis()}
                  disabled={agentLoading}
                  className="inline-flex items-center gap-1 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs text-white hover:bg-indigo-700 disabled:opacity-60"
                >
                  <Plus className="h-3.5 w-3.5" />
                  Suggest KPIs
                </button>
                <span className="text-[11px] text-slate-500">{visibleAgentCandidates.length} candidates</span>
              </div>
              {agentNotes.length > 0 ? (
                <ul className="list-disc space-y-1 pl-4 text-[11px] text-slate-700">
                  {agentNotes.map((note) => (
                    <li key={note}>{note}</li>
                  ))}
                </ul>
              ) : null}
            </div>

            <div className="rounded-lg border border-slate-200 bg-white p-3">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold text-slate-700">Suggested KPIs</p>
                <span className="text-[11px] text-slate-500">{visibleAgentCandidates.length} visible</span>
              </div>
              <div className="mt-2 max-h-80 overflow-auto space-y-2">
                {visibleAgentCandidates.map((candidate) => (
                  <div key={candidate.id} className="rounded border border-slate-200 p-2">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-xs font-medium text-slate-900">{candidate.display_name || candidate.id}</p>
                      <p className="text-[10px] text-slate-500">{candidate.id}</p>
                    </div>
                    <p className="mt-1 font-mono text-[10px] text-slate-600">{candidate.formula}</p>
                    <p className="mt-1 text-[10px] text-slate-600">{(candidate.marts || []).join(", ") || "-"}</p>
                    {agentMissingById[candidate.id] ? (
                      <p className="mt-1 text-[10px] text-amber-700">{agentMissingById[candidate.id]}</p>
                    ) : null}
                    {(agentColumnMatchesById[candidate.id] || []).length > 0 ? (
                      <p className="mt-1 text-[10px] text-slate-600">{agentColumnMatchesById[candidate.id].join(" | ")}</p>
                    ) : null}
                    <div className="mt-2 flex gap-1">
                      <button
                        type="button"
                        onClick={() => void addSuggestedKpi(candidate)}
                        disabled={addingCandidateId === candidate.id}
                        className="rounded border border-indigo-300 px-2 py-0.5 text-[10px] text-indigo-700 hover:bg-indigo-50 disabled:opacity-60"
                      >
                        {addingCandidateId === candidate.id ? "Adding..." : "Add KPI"}
                      </button>
                      <button
                        type="button"
                        onClick={() => ignoreSuggestedKpi(candidate.id)}
                        className="rounded border border-slate-300 px-2 py-0.5 text-[10px] text-slate-700 hover:bg-slate-100"
                      >
                        Ignore
                      </button>
                    </div>
                  </div>
                ))}
                {visibleAgentCandidates.length === 0 ? (
                  <p className="text-xs text-slate-500">No candidates yet.</p>
                ) : null}
              </div>
            </div>

            <div className="rounded-lg border border-slate-200 bg-white p-3 space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold text-slate-700">Patch Center</p>
                <span className="text-[11px] text-slate-500">{unresolvedSuggestionCount} unresolved</span>
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => void applySelectedAgentPatches(selectedPatchIds)}
                  disabled={agentApplying || selectedPatchIds.length === 0}
                  className="rounded border border-indigo-300 px-2 py-1 text-[11px] text-indigo-700 hover:bg-indigo-50 disabled:opacity-60"
                >
                  {agentApplying ? "Applying..." : "Apply Selected"}
                </button>
                <button
                  type="button"
                  onClick={() => void applyAllSafeAgentPatches()}
                  disabled={agentApplying || agentPatches.length === 0}
                  className="rounded border border-slate-300 px-2 py-1 text-[11px] text-slate-700 hover:bg-slate-100 disabled:opacity-60"
                >
                  Apply All Safe Fixes
                </button>
                <button
                  type="button"
                  onClick={() => void undoLastPatchApply()}
                  disabled={agentUndoing || !lastApplyBaseRevision}
                  className="rounded border border-red-300 px-2 py-1 text-[11px] text-red-700 hover:bg-red-50 disabled:opacity-60"
                >
                  {agentUndoing ? "Undoing..." : "Undo Last Apply"}
                </button>
              </div>
              <div className="max-h-80 space-y-2 overflow-auto">
                {agentPatches.map((patch) => {
                  const descriptor = describePatch(patch, kpiLabelById);
                  return (
                    <label key={patch.patch_id} className="block rounded border border-slate-200 p-2 text-[11px]">
                      <div className="flex items-start gap-2">
                        <input
                          type="checkbox"
                          checked={selectedPatchIds.includes(patch.patch_id)}
                          onChange={(event) =>
                            setSelectedPatchIds((prev) =>
                              event.target.checked
                                ? prev.includes(patch.patch_id)
                                  ? prev
                                  : [...prev, patch.patch_id]
                                : prev.filter((item) => item !== patch.patch_id)
                            )
                          }
                          className="mt-0.5"
                        />
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-medium text-slate-800">{descriptor.title}</span>
                            <span className="rounded-full bg-slate-100 px-1.5 py-0.5 text-[10px] text-slate-600">
                              {(patch.confidence * 100).toFixed(0)}%
                            </span>
                            <span className="rounded-full bg-indigo-50 px-1.5 py-0.5 text-[10px] text-indigo-700">
                              {humanizeIdentifier(patch.type)}
                            </span>
                          </div>
                          {descriptor.subtitle ? <p className="mt-1 text-slate-500">{descriptor.subtitle}</p> : null}
                          <p className="mt-1 text-slate-700">{descriptor.summary}</p>
                          <p className="mt-1 text-slate-600">{patch.rationale}</p>
                          <p className="mt-1 text-[10px] text-slate-500">
                            Patch ID {patch.patch_id} • Source {patch.source}
                          </p>
                        </div>
                      </div>
                    </label>
                  );
                })}
                {agentPatches.length === 0 ? (
                  <p className="text-xs text-slate-500">No patch suggestions yet.</p>
                ) : null}
              </div>
            </div>
          </div>
          {ignoredCandidateIds.length > 0 ? (
            <div className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-600">
              Ignored suggestions: {ignoredCandidateIds.join(", ")}
            </div>
          ) : null}
        </div>
      ) : null}

      {section === "evaluation" ? (
        <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">Evaluation</h3>
              <p className="text-xs text-slate-600">
                Decision surface combining KPI execution, triggered rules, and recommended actions.
              </p>
            </div>
            <button
              type="button"
              onClick={() => void runEvaluation()}
              disabled={evaluationLoading}
              className="inline-flex items-center gap-1 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs text-white hover:bg-indigo-700 disabled:opacity-60"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              {evaluationLoading ? "Evaluating..." : "Run Evaluation"}
            </button>
          </div>

          {evaluationState ? (
            <div className="space-y-3">
              <div className="grid grid-cols-1 gap-3 md:grid-cols-5">
                <div className="rounded-xl border border-indigo-200 bg-white p-3">
                  <p className="text-xs text-slate-500">Overall Readiness</p>
                  <p className="text-lg font-semibold text-indigo-700">{scoreText(decisionSignalsState?.executive_summary?.overall_readiness_score ?? readiness?.overall_score ?? 0)}</p>
                </div>
                <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-3">
                  <p className="text-xs text-slate-500">On Track</p>
                  <p className="text-lg font-semibold text-emerald-700">{decisionSignalsState?.executive_summary?.kpis_on_track ?? evaluationSummary?.onTrack ?? 0}</p>
                </div>
                <div className="rounded-xl border border-amber-200 bg-amber-50 p-3">
                  <p className="text-xs text-slate-500">Warning</p>
                  <p className="text-lg font-semibold text-amber-700">{decisionSignalsState?.executive_summary?.kpis_warning ?? evaluationSummary?.warning ?? 0}</p>
                </div>
                <div className="rounded-xl border border-red-200 bg-red-50 p-3">
                  <p className="text-xs text-slate-500">Critical</p>
                  <p className="text-lg font-semibold text-red-700">{decisionSignalsState?.executive_summary?.kpis_critical ?? evaluationSummary?.critical ?? 0}</p>
                </div>
                <div className="rounded-xl border border-slate-200 bg-white p-3">
                  <p className="text-xs text-slate-500">Triggered Rules</p>
                  <p className="text-lg font-semibold text-slate-800">{decisionSignalsState?.executive_summary?.triggered_rules ?? evaluationSummary?.triggeredRules ?? 0}</p>
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
                <p className="text-xs font-medium text-slate-700">Executive Summary</p>
                <p className="mt-1 text-sm text-slate-700">
                  {decisionSignalsState?.executive_summary?.narrative ||
                    "Run evaluation to generate a narrative summary of growth, retention, margin, and inventory posture."}
                </p>
                {(decision?.readiness_notes || []).length > 0 ? (
                  <ul className="mt-2 list-disc pl-4 text-xs text-slate-600">
                    {(decision?.readiness_notes || []).map((note) => (
                      <li key={`readiness-note-${note}`}>{note}</li>
                    ))}
                  </ul>
                ) : null}
              </div>

              <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
                <div className="rounded-xl border border-slate-200 bg-white p-3">
                  <p className="text-xs font-semibold text-slate-700">Decision Signals</p>
                  {(decisionSignalsState?.decision_signals || []).length === 0 ? (
                    <p className="mt-2 text-xs text-slate-500">No active decision signals.</p>
                  ) : (
                    <div className="mt-2 space-y-2">
                      {(decisionSignalsState?.decision_signals || []).map((signal) => (
                        <div key={signal.id} className="rounded border border-slate-200 p-2">
                          <div className="flex items-center justify-between gap-2">
                            <p className="text-xs font-medium text-slate-900">{signal.title}</p>
                            <span
                              className={`rounded-full px-2 py-0.5 text-[10px] ${
                                signal.severity === "critical"
                                  ? "bg-red-100 text-red-700"
                                  : signal.severity === "warn"
                                  ? "bg-amber-100 text-amber-700"
                                  : "bg-slate-100 text-slate-700"
                              }`}
                            >
                              {signal.severity}
                            </span>
                          </div>
                          <p className="mt-1 text-[11px] text-slate-600">{signal.explanation}</p>
                          <p className="mt-1 text-[11px] text-indigo-700">{signal.suggested_action}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <div className="rounded-xl border border-slate-200 bg-white p-3">
                  <p className="text-xs font-semibold text-slate-700">Recommendations</p>
                  {(decisionSignalsState?.recommendations || []).length === 0 ? (
                    <p className="mt-2 text-xs text-slate-500">No recommendations generated.</p>
                  ) : (
                    <ul className="mt-2 list-disc space-y-1 pl-4 text-xs text-slate-700">
                      {(decisionSignalsState?.recommendations || []).map((item) => (
                        <li key={`recommendation-${item}`}>{item}</li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 bg-white p-3">
                <p className="text-xs font-semibold text-slate-700">KPI Status Table</p>
                <div className="mt-2 overflow-x-auto">
                  <table className="min-w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500">
                        <th className="px-2 py-2">KPI</th>
                        <th className="px-2 py-2">Actual</th>
                        <th className="px-2 py-2">Target</th>
                        <th className="px-2 py-2">Variance</th>
                        <th className="px-2 py-2">Status</th>
                        <th className="px-2 py-2">Pillar</th>
                        <th className="px-2 py-2">Owner</th>
                        <th className="px-2 py-2">Computability</th>
                        <th className="px-2 py-2">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(evaluationState.kpis || []).map((item) => {
                        const statusClass =
                          item.status === "green"
                            ? "bg-emerald-100 text-emerald-700"
                            : item.status === "yellow"
                            ? "bg-amber-100 text-amber-700"
                            : item.status === "red"
                            ? "bg-red-100 text-red-700"
                            : "bg-slate-100 text-slate-700";
                        const valueText = (value: number | null) =>
                          value == null ? "-" : Number(value).toLocaleString(undefined, { maximumFractionDigits: 4 });
                        const computabilityClass = item.computable ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700";
                        return (
                          <tr key={`evaluation-kpi-${item.id}`} className="border-b border-slate-100">
                            <td className="px-2 py-2">
                              <div className="font-medium text-slate-900">{item.display_name || item.id}</div>
                              <div className="text-[10px] text-slate-500">{item.id}</div>
                            </td>
                            <td className="px-2 py-2">{valueText(item.value)}</td>
                            <td className="px-2 py-2">{valueText(item.target)}</td>
                            <td className="px-2 py-2">{valueText(item.variance)}</td>
                            <td className="px-2 py-2">
                              <span className={`rounded-full px-2 py-0.5 text-[10px] ${statusClass}`}>{item.status}</span>
                            </td>
                            <td className="px-2 py-2">{item.pillar_id || "-"}</td>
                            <td className="px-2 py-2">{item.owner || "-"}</td>
                            <td className="px-2 py-2">
                              <span className={`rounded-full px-2 py-0.5 text-[10px] ${computabilityClass}`}>
                                {item.computable ? "computable" : item.dependency_status || "unresolved"}
                              </span>
                            </td>
                            <td className="px-2 py-2">
                              <div className="flex flex-wrap gap-1">
                                <button
                                  type="button"
                                  onClick={() => openInAnalytics({
                                    id: item.id,
                                    display_name: item.display_name,
                                    formula: item.formula || "",
                                    marts: item.marts || [],
                                    required_columns: item.required_columns || [],
                                    dimensions: item.dimensions || [],
                                  })}
                                  className="inline-flex items-center gap-1 rounded border border-indigo-300 px-2 py-0.5 text-[10px] text-indigo-700 hover:bg-indigo-50"
                                >
                                  <BarChart3 className="h-3 w-3" />
                                  Inspect
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setSelectedEvaluationKpi(item)}
                                  className="rounded border border-slate-300 px-2 py-0.5 text-[10px] hover:bg-slate-100"
                                >
                                  View details
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                      {(evaluationState.kpis || []).length === 0 ? (
                        <tr>
                          <td colSpan={9} className="px-2 py-4 text-center text-slate-500">
                            No KPI evaluation results returned.
                          </td>
                        </tr>
                      ) : null}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 bg-white p-3">
                <p className="text-xs font-semibold text-slate-700">Triggered Rules</p>
                <div className="mt-2 grid grid-cols-1 gap-3 lg:grid-cols-3">
                  {(["critical", "warn", "info"] as const).map((bucket) => (
                    <div key={`bucket-${bucket}`} className="rounded border border-slate-200 p-2">
                      <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-600">{bucket}</p>
                      {(groupedTriggeredRules[bucket] || []).length === 0 ? (
                        <p className="mt-2 text-[11px] text-slate-500">None</p>
                      ) : (
                        <div className="mt-2 space-y-2">
                          {groupedTriggeredRules[bucket].map((rule) => (
                            <div key={`triggered-${bucket}-${rule.id}`} className="rounded border border-slate-200 p-2">
                              <p className="text-[11px] font-medium text-slate-900">{rule.id}</p>
                              <p className="mt-1 font-mono text-[10px] text-slate-600">{rule.condition}</p>
                              {rule.rationale ? <p className="mt-1 text-[10px] text-slate-600">{rule.rationale}</p> : null}
                              <p className="mt-1 text-[10px] text-indigo-700">{rule.action}</p>
                              <p className="mt-1 text-[10px] text-slate-500">Affected KPI(s): {(rule.affected_kpis || []).join(", ") || "-"}</p>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-4 text-xs text-slate-600">
              Run evaluation to generate summary cards, KPI status, triggered rules, and decision signals.
            </div>
          )}
        </div>
      ) : null}

      {section === "advanced_yaml" ? (
        <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="text-xs font-semibold text-slate-700">Advanced YAML (Fallback)</p>
              <p className="text-[11px] text-slate-500">
                Revision: <span className="font-mono text-slate-700">{revision ?? "n/a"}</span>. Prefer structured tabs for routine edits.
              </p>
            </div>
            <button
              type="button"
              onClick={() => void refreshYamlEditors()}
              className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              Refresh Latest
            </button>
          </div>
          <div className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
            Structured UI is recommended for safer updates. Use YAML only for advanced bulk changes.
          </div>
          {yamlValidationMessage ? (
            <div className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-700">
              {yamlValidationMessage}
            </div>
          ) : null}
          <div className="flex items-center gap-2">
            <button type="button" onClick={() => setEditor("strategy")} className={`rounded-lg px-3 py-1.5 text-xs border ${editor === "strategy" ? "border-indigo-300 bg-indigo-100 text-indigo-700" : "border-slate-300 bg-white text-slate-700"}`}>Strategy Bundle</button>
            <button type="button" onClick={() => setEditor("kpi")} className={`rounded-lg px-3 py-1.5 text-xs border ${editor === "kpi" ? "border-indigo-300 bg-indigo-100 text-indigo-700" : "border-slate-300 bg-white text-slate-700"}`}>KPI Registry</button>
          </div>
          <div className="mt-3 flex items-center justify-between">
            <label className="inline-flex items-center gap-2 text-xs text-slate-700">
              <input type="checkbox" checked={editor === "strategy" ? strategyMode === "override" : kpiMode === "override"} onChange={(event) => editor === "strategy" ? setStrategyMode(event.target.checked ? "override" : "base") : setKpiMode(event.target.checked ? "override" : "base")} />
              Edit override YAML
            </label>
            <button type="button" onClick={() => void saveYaml()} disabled={saving} className="inline-flex items-center gap-1 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs text-white hover:bg-indigo-700 disabled:opacity-60"><Save className="h-3.5 w-3.5" />Save</button>
          </div>
          <textarea value={editor === "strategy" ? strategyText : kpiText} onChange={(event) => editor === "strategy" ? setStrategyText(event.target.value) : setKpiText(event.target.value)} className="mt-2 h-72 w-full rounded-lg border border-slate-300 bg-slate-50 p-3 font-mono text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-400" />
        </div>
      ) : null}

      {selectedEvaluationKpi ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
          <div className="w-full max-w-2xl rounded-xl border border-slate-200 bg-white p-4 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900">KPI Details: {selectedEvaluationKpi.display_name || selectedEvaluationKpi.id}</h3>
              <button type="button" onClick={() => setSelectedEvaluationKpi(null)} className="rounded-lg p-1 hover:bg-slate-100">
                <X className="h-4 w-4 text-slate-600" />
              </button>
            </div>
            <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2">
              <div className="rounded border border-slate-200 bg-slate-50 px-3 py-2 text-xs">
                <p className="font-medium text-slate-700">Formula</p>
                <p className="mt-1 font-mono text-[11px] text-slate-800">{selectedEvaluationKpi.formula || "-"}</p>
              </div>
              <div className="rounded border border-slate-200 bg-slate-50 px-3 py-2 text-xs">
                <p className="font-medium text-slate-700">Owner / Pillar</p>
                <p className="mt-1 text-slate-800">{selectedEvaluationKpi.owner || "-"} / {selectedEvaluationKpi.pillar_id || "-"}</p>
              </div>
              <div className="rounded border border-slate-200 bg-slate-50 px-3 py-2 text-xs">
                <p className="font-medium text-slate-700">Marts</p>
                <p className="mt-1 text-slate-800">{(selectedEvaluationKpi.marts || []).join(", ") || "-"}</p>
              </div>
              <div className="rounded border border-slate-200 bg-slate-50 px-3 py-2 text-xs">
                <p className="font-medium text-slate-700">Required Columns</p>
                <p className="mt-1 text-slate-800">{(selectedEvaluationKpi.required_columns || []).join(", ") || "-"}</p>
              </div>
              <div className="rounded border border-slate-200 bg-slate-50 px-3 py-2 text-xs md:col-span-2">
                <p className="font-medium text-slate-700">Target & Status</p>
                <p className="mt-1 text-slate-800">
                  Target: {selectedEvaluationKpi.target ?? "-"} | Status: {selectedEvaluationKpi.status} | Computability: {selectedEvaluationKpi.computable ? "computable" : (selectedEvaluationKpi.dependency_status || "unresolved")}
                </p>
              </div>
              <div className="rounded border border-slate-200 bg-slate-50 px-3 py-2 text-xs md:col-span-2">
                <p className="font-medium text-slate-700">Linked Rules</p>
                <div className="mt-1 text-slate-800">
                  {evaluationState?.triggered_rules?.filter((rule) => (rule.affected_kpis || []).includes(selectedEvaluationKpi.id)).length ? (
                    <ul className="list-disc pl-4">
                      {evaluationState.triggered_rules
                        .filter((rule) => (rule.affected_kpis || []).includes(selectedEvaluationKpi.id))
                        .map((rule) => (
                          <li key={`kpi-rule-${rule.id}`}>{rule.id}: {rule.action}</li>
                        ))}
                    </ul>
                  ) : (
                    <span>No triggered rules for this KPI in the last evaluation.</span>
                  )}
                </div>
              </div>
              <div className="rounded border border-slate-200 bg-slate-50 px-3 py-2 text-xs md:col-span-2">
                <p className="font-medium text-slate-700">Provenance</p>
                <pre className="mt-1 max-h-48 overflow-auto whitespace-pre-wrap rounded bg-white p-2 text-[10px] text-slate-700">
{JSON.stringify(selectedEvaluationKpi.provenance || {}, null, 2)}
                </pre>
              </div>
            </div>
            <div className="mt-4">
              <DecisionIntelligencePanel
                datasetId={datasetId}
                martId={selectedEvaluationKpi.marts?.[0] ?? null}
                chartTitle={selectedEvaluationKpi.display_name || selectedEvaluationKpi.id}
                kpiId={selectedEvaluationKpi.id}
                analysisSource="strategy"
                analysisContext={selectedKpiAnalysisContext}
              />
            </div>
            <div className="mt-4 flex items-center justify-end">
              <button
                type="button"
                onClick={() => openInAnalytics({
                  id: selectedEvaluationKpi.id,
                  display_name: selectedEvaluationKpi.display_name,
                  formula: selectedEvaluationKpi.formula || "",
                  marts: selectedEvaluationKpi.marts || [],
                  required_columns: selectedEvaluationKpi.required_columns || [],
                  dimensions: selectedEvaluationKpi.dimensions || [],
                })}
                className="mr-2 inline-flex items-center gap-1 rounded-lg border border-indigo-300 px-3 py-1.5 text-xs text-indigo-700 hover:bg-indigo-50"
              >
                <BarChart3 className="h-3.5 w-3.5" />
                Inspect in Analytics
              </button>
              <button type="button" onClick={() => setSelectedEvaluationKpi(null)} className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50">Close</button>
            </div>
          </div>
        </div>
      ) : null}

      {targetModalOpen ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
          <div className="w-full max-w-lg rounded-xl border border-slate-200 bg-white p-4 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900">{targetFormMode === "edit" ? "Edit Target" : "Add Target"}</h3>
              <button type="button" onClick={closeTargetModal} className="rounded-lg p-1 hover:bg-slate-100">
                <X className="h-4 w-4 text-slate-600" />
              </button>
            </div>
            <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2">
              <select
                value={targetDraft.kpi_id}
                onChange={(event) => setTargetDraft((prev) => ({ ...prev, kpi_id: event.target.value }))}
                disabled={targetFormMode === "edit"}
                className="rounded border border-slate-300 px-2 py-1.5 text-xs md:col-span-2"
              >
                <option value="">Select KPI</option>
                {(targetsState?.available_kpis || kpis.map((item) => item.id)).map((kpiId) => (
                  <option key={kpiId} value={kpiId}>
                    {kpiId}
                  </option>
                ))}
              </select>
              <input
                type="number"
                value={targetDraft.target_value}
                onChange={(event) => setTargetDraft((prev) => ({ ...prev, target_value: Number(event.target.value) }))}
                placeholder="Target"
                className="rounded border border-slate-300 px-2 py-1.5 text-xs"
              />
              <select
                value={targetDraft.direction}
                onChange={(event) => setTargetDraft((prev) => ({ ...prev, direction: event.target.value as "up" | "down" }))}
                className="rounded border border-slate-300 px-2 py-1.5 text-xs"
              >
                <option value="up">up</option>
                <option value="down">down</option>
              </select>
              <input
                type="number"
                value={targetDraft.yellow_threshold ?? ""}
                onChange={(event) =>
                  setTargetDraft((prev) => ({
                    ...prev,
                    yellow_threshold: event.target.value === "" ? null : Number(event.target.value),
                  }))
                }
                placeholder="Yellow threshold"
                className="rounded border border-slate-300 px-2 py-1.5 text-xs"
              />
              <input
                type="number"
                value={targetDraft.red_threshold ?? ""}
                onChange={(event) =>
                  setTargetDraft((prev) => ({
                    ...prev,
                    red_threshold: event.target.value === "" ? null : Number(event.target.value),
                  }))
                }
                placeholder="Red threshold"
                className="rounded border border-slate-300 px-2 py-1.5 text-xs"
              />
              <input
                value={targetDraft.owner || ""}
                onChange={(event) => setTargetDraft((prev) => ({ ...prev, owner: event.target.value }))}
                placeholder="Owner"
                className="rounded border border-slate-300 px-2 py-1.5 text-xs"
              />
              <input
                value={targetDraft.horizon || ""}
                onChange={(event) => setTargetDraft((prev) => ({ ...prev, horizon: event.target.value }))}
                placeholder="Horizon"
                className="rounded border border-slate-300 px-2 py-1.5 text-xs"
              />
            </div>
            <div className="mt-4 flex items-center justify-end gap-2">
              <button type="button" onClick={closeTargetModal} className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50">Cancel</button>
              <button type="button" onClick={() => void saveTarget()} disabled={saving} className="rounded-lg bg-indigo-600 px-3 py-1.5 text-xs text-white hover:bg-indigo-700 disabled:opacity-60">Save Target</button>
            </div>
          </div>
        </div>
      ) : null}

      {ruleModalOpen ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
          <div className="w-full max-w-lg rounded-xl border border-slate-200 bg-white p-4 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900">{ruleFormMode === "edit" ? "Edit Rule" : "Add Rule"}</h3>
              <button type="button" onClick={closeRuleModal} className="rounded-lg p-1 hover:bg-slate-100">
                <X className="h-4 w-4 text-slate-600" />
              </button>
            </div>
            <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2">
              <input
                value={ruleDraft.id}
                onChange={(event) => setRuleDraft((prev) => ({ ...prev, id: event.target.value }))}
                placeholder="Rule id"
                disabled={ruleFormMode === "edit"}
                className="rounded border border-slate-300 px-2 py-1.5 text-xs"
              />
              <select
                value={ruleDraft.severity}
                onChange={(event) =>
                  setRuleDraft((prev) => ({ ...prev, severity: event.target.value as "info" | "warn" | "block" }))
                }
                className="rounded border border-slate-300 px-2 py-1.5 text-xs"
              >
                <option value="info">info</option>
                <option value="warn">warn</option>
                <option value="block">block</option>
              </select>
              <select
                value={ruleDraft.kpi_id}
                onChange={(event) => setRuleDraft((prev) => ({ ...prev, kpi_id: event.target.value }))}
                className="rounded border border-slate-300 px-2 py-1.5 text-xs"
              >
                <option value="">Select KPI</option>
                {(rulesState?.available_kpis || kpis.map((item) => item.id)).map((kpiId) => (
                  <option key={kpiId} value={kpiId}>
                    {kpiId}
                  </option>
                ))}
              </select>
              <select
                value={ruleDraft.operator}
                onChange={(event) =>
                  setRuleDraft((prev) => ({ ...prev, operator: event.target.value as RuleDraft["operator"] }))
                }
                className="rounded border border-slate-300 px-2 py-1.5 text-xs"
              >
                <option value="<">&lt;</option>
                <option value="<=">&lt;=</option>
                <option value=">">&gt;</option>
                <option value=">=">&gt;=</option>
                <option value="==">==</option>
              </select>
              <input
                value={ruleDraft.threshold}
                onChange={(event) => setRuleDraft((prev) => ({ ...prev, threshold: event.target.value }))}
                placeholder="Threshold"
                className="rounded border border-slate-300 px-2 py-1.5 text-xs"
              />
              <input
                value={ruleDraft.action}
                onChange={(event) => setRuleDraft((prev) => ({ ...prev, action: event.target.value }))}
                placeholder="Action"
                className="rounded border border-slate-300 px-2 py-1.5 text-xs"
              />
              <textarea
                value={ruleDraft.rationale}
                onChange={(event) => setRuleDraft((prev) => ({ ...prev, rationale: event.target.value }))}
                placeholder="Rationale"
                className="h-20 rounded border border-slate-300 px-2 py-1.5 text-xs md:col-span-2"
              />
              <div className="rounded border border-slate-200 bg-slate-50 px-2 py-2 text-[11px] text-slate-700 md:col-span-2">
                Condition: <span className="font-mono">{generatedRuleCondition}</span>
              </div>
            </div>
            <div className="mt-4 flex items-center justify-end gap-2">
              <button type="button" onClick={closeRuleModal} className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50">Cancel</button>
              <button type="button" onClick={() => void saveRule()} disabled={saving} className="rounded-lg bg-indigo-600 px-3 py-1.5 text-xs text-white hover:bg-indigo-700 disabled:opacity-60">Save Rule</button>
            </div>
          </div>
        </div>
      ) : null}

      {modalOpen ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
          <div className="w-full max-w-2xl rounded-xl border border-slate-200 bg-white p-4 shadow-xl">
            <div className="flex items-center justify-between"><h3 className="text-sm font-semibold text-slate-900">{formMode === "edit" ? "Edit KPI" : formMode === "duplicate" ? "Duplicate KPI" : "Add KPI"}</h3><button type="button" onClick={closeModal} className="rounded-lg p-1 hover:bg-slate-100"><X className="h-4 w-4 text-slate-600" /></button></div>
            <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2">
              <input value={draft.id} onChange={(event) => setDraft((prev) => ({ ...prev, id: event.target.value }))} placeholder="id" className="rounded border border-slate-300 px-2 py-1.5 text-xs" />
              <input value={draft.display_name || ""} onChange={(event) => setDraft((prev) => ({ ...prev, display_name: event.target.value }))} placeholder="display name" className="rounded border border-slate-300 px-2 py-1.5 text-xs" />
              <input value={draft.description} onChange={(event) => setDraft((prev) => ({ ...prev, description: event.target.value }))} placeholder="description" className="rounded border border-slate-300 px-2 py-1.5 text-xs md:col-span-2" />
              <input value={draft.formula} onChange={(event) => setDraft((prev) => ({ ...prev, formula: event.target.value }))} placeholder="formula" className="rounded border border-slate-300 px-2 py-1.5 text-xs md:col-span-2" />
              <input value={dimensionsDraft} onChange={(event) => setDimensionsDraft(event.target.value)} placeholder="dimensions (comma-separated)" className="rounded border border-slate-300 px-2 py-1.5 text-xs" />
              <input value={draft.pillar_id || ""} onChange={(event) => setDraft((prev) => ({ ...prev, pillar_id: event.target.value }))} placeholder="pillar_id" className="rounded border border-slate-300 px-2 py-1.5 text-xs" />
              <input value={draft.owner || ""} onChange={(event) => setDraft((prev) => ({ ...prev, owner: event.target.value }))} placeholder="owner" className="rounded border border-slate-300 px-2 py-1.5 text-xs" />
              <select value={draft.default_grain || ""} onChange={(event) => setDraft((prev) => ({ ...prev, default_grain: event.target.value }))} className="rounded border border-slate-300 px-2 py-1.5 text-xs"><option value="">default grain</option><option value="day">day</option><option value="week">week</option><option value="month">month</option><option value="quarter">quarter</option><option value="year">year</option></select>
              <textarea
                value={derivedMetricsDraft}
                onChange={(event) => setDerivedMetricsDraft(event.target.value)}
                placeholder={"derived metrics (one per line)\nexample: margin_pct=sum(margin)/sum(net_sales)"}
                className="h-24 rounded border border-slate-300 px-2 py-1.5 text-xs md:col-span-2"
              />
              <div className="md:col-span-2 rounded border border-slate-200 p-2"><p className="text-[11px] text-slate-600 mb-1">Marts</p><div className="grid grid-cols-2 gap-2">{availableMarts.map((mart) => <label key={mart} className="inline-flex items-center gap-2 text-xs text-slate-700"><input type="checkbox" checked={(draft.marts || []).includes(mart)} onChange={(event) => setDraft((prev) => { const next = new Set(prev.marts || []); if (event.target.checked) next.add(mart); else next.delete(mart); return { ...prev, marts: Array.from(next) }; })} />{mart}</label>)}</div></div>
              <div className="md:col-span-2 rounded border border-slate-200 p-2"><p className="text-[11px] text-slate-600 mb-1">Required Columns</p><div className="grid grid-cols-2 gap-2 max-h-32 overflow-y-auto">{draftColumns.map((column) => <label key={column} className="inline-flex items-center gap-2 text-xs text-slate-700"><input type="checkbox" checked={(draft.required_columns || []).includes(column)} onChange={(event) => setDraft((prev) => { const next = new Set(prev.required_columns || []); if (event.target.checked) next.add(column); else next.delete(column); return { ...prev, required_columns: Array.from(next) }; })} />{column}</label>)}</div></div>
              <div className="md:col-span-2 rounded border border-slate-200 p-2">
                <p className="text-[11px] text-slate-600 mb-1">Dependency Preview</p>
                <div className="space-y-1 text-[11px] text-slate-700">
                  {draftDependencyPreview.map((entry) => (
                    <div key={`dep-${entry.mart}`}>
                      <span className="font-medium">{entry.mart}</span>
                      <span className="ml-2">required: {(entry.required || []).join(", ") || "-"}</span>
                      <span className={`ml-2 ${entry.missing.length === 0 ? "text-emerald-700" : "text-red-700"}`}>
                        {entry.missing.length === 0 ? "all available" : `missing: ${entry.missing.join(", ")}`}
                      </span>
                    </div>
                  ))}
                  {draftDependencyPreview.length === 0 ? <div>No marts selected.</div> : null}
                </div>
              </div>
            </div>
            <div className="mt-4 flex items-center justify-end gap-2">
              <button type="button" onClick={closeModal} className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50">Cancel</button>
              <button type="button" onClick={() => void saveKpi()} disabled={saving} className="rounded-lg bg-indigo-600 px-3 py-1.5 text-xs text-white hover:bg-indigo-700 disabled:opacity-60">Save KPI</button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

