# Core module initialization
