from __future__ import annotations
from typing import Any, Dict, Optional, Tuple, Iterable
import os
import pandas as pd
from sqlalchemy import create_engine, text
from app.core.config import settings

# Env-configurable view names for DB mode
DEFAULT_SALES_VIEW = os.getenv("SALES_VIEW", "SalesSummary")
DEFAULT_OPP_VIEW   = os.getenv("OPPORTUNITY_VIEW", "OpportunitySummary")

# ---------------------------
# Helpers: dtypes & renaming
# ---------------------------
def _coalesce_to(df: pd.DataFrame, target: str, candidates: list[str]) -> pd.DataFrame:
    """
    Create/normalize a single canonical `target` column by coalescing values
    from the first available candidates (in order). Drop the extra columns.
    Works even if none are present (creates target with NA).
    """
    # Use only distinct labels that actually exist
    exist = []
    seen = set()
    for c in candidates:
        if c in df.columns and c not in seen:
            exist.append(c)
            seen.add(c)

    if not exist:
        if target not in df.columns:
            df[target] = pd.NA
        return df

    # Start with the first
    s = df[exist[0]].copy()
    for c in exist[1:]:
        s = s.combine_first(df[c])

    df[target] = s

    # Drop the other synonyms (keep the canonical target)
    for c in exist:
        if c != target and c in df.columns:
            df.drop(columns=[c], inplace=True, errors="ignore")
    return df


def _dedup_columns_inplace(df: pd.DataFrame) -> None:
    """
    If the same label appears more than once, keep the first occurrence.
    This avoids 'label not unique' errors when selecting df[col].
    """
    if df.columns.duplicated().any():
        df.drop(columns=df.columns[df.columns.duplicated(keep='first')], inplace=True)

def _ensure_col(df: pd.DataFrame, target: str, candidates: list[str]) -> pd.DataFrame:
    """Make sure df has `target` column by renaming the first matching candidate."""
    if target in df.columns:
        return df
    hit = _first_present(df.columns, candidates)
    if hit:
        return df.rename(columns={hit: target})
    return df

def _to_str_id(s: pd.Series) -> pd.Series:
    if isinstance(s, pd.DataFrame):
        s = s.iloc[:, 0]
    if s.dtype.kind in ("i", "u", "f", "b"):
        s = s.astype("string")
    else:
        s = s.astype("string", copy=False)
    s = s.str.strip()
    s = s.str.replace(r"\.0$", "", regex=True)
    return s.fillna(pd.NA)


def _to_num(s: pd.Series) -> pd.Series:
    return pd.to_numeric(s, errors="coerce")

def _read_sql(engine, sql: str) -> pd.DataFrame:
    with engine.connect() as conn:
        return pd.read_sql(text(sql), conn)

def _first_present(cols: Iterable[str], candidates: Iterable[str]) -> str | None:
    low = {c.lower(): c for c in cols}
    for cand in candidates:
        if cand.lower() in low:
            return low[cand.lower()]
    return None

def _ensure_id(df: pd.DataFrame, candidates: list[str]) -> pd.DataFrame:
    if "id" in df.columns:
        return df
    hit = _first_present(df.columns, candidates)
    if not hit:
        df = df.copy()
        df["id"] = range(1, len(df) + 1)
        return df
    return df.rename(columns={hit: "id"})

def _alias(df: pd.DataFrame, mapping: Dict[str, str]) -> pd.DataFrame:
    rename = {}
    low = {c.lower(): c for c in df.columns}
    for src, dst in mapping.items():
        if src.lower() in low and low[src.lower()] != dst:
            rename[low[src.lower()]] = dst
    return df.rename(columns=rename)

# ---------------------------
# CSV loader (processed dir)
# ---------------------------
def _load_from_csv(base_dir: str) -> Tuple[pd.DataFrame, pd.DataFrame]:
    def p(name: str) -> str:
        return os.path.join(base_dir, name)

    # --- load
    sales     = pd.read_csv(p("sales_transactions_enriched.csv"))
    products  = pd.read_csv(p("products.csv"))
    customers = pd.read_csv(p("customers.csv"))
    salesreps = pd.read_csv(p("salesreps.csv"))
    regions   = pd.read_csv(p("regions.csv"))
    opp_path  = p("opportunities.csv")
    opp       = pd.read_csv(opp_path) if os.path.exists(opp_path) else pd.DataFrame()

    # --- normalize column names: strip + lowercase
    for df in (sales, products, customers, salesreps, regions, opp):
        if not df.empty:
            df.columns = [c.strip().lower() for c in df.columns]

    # Ensure there are no exact duplicate labels before any renames/aliases
    for _df in (sales, products, customers, salesreps, regions, opp):
        _dedup_columns_inplace(_df)

    # --- after lowercasing columns for all CSVs ---
    # Hard-guarantee foreign keys exist on the sales fact before any merges.
    # This prevents KeyError: 'region_id' (or similar) during the joins below.
    if "region_id" not in sales.columns:
        # Some ETL exports use a human 'region' label instead of an id.
        if "region" in sales.columns:
            # keep as string id; downstream merges will still succeed because
            # regions.csv is normalized to id string as well.
            sales["region_id"] = sales["region"].astype("string")
        else:
            sales["region_id"] = pd.NA

    for fk in ("product_id", "customer_id", "sales_rep_id"):
        if fk not in sales.columns:
            sales[fk] = pd.NA

    # ----- normalize dimension IDs -----
    products  = _ensure_id(products,  ["product id","product_id","prod_id","id"])
    customers = _ensure_id(customers, ["customer id","customer_id","cust_id","id"])
    salesreps = _ensure_id(salesreps, ["salesrep id","sales_rep_id","salesrep_id","rep_id","id"])
    regions   = _ensure_id(regions,   ["region id","region_id","id"])

    # Make all dimension IDs strings so they match the sales/opp FKs
    for _dim in (products, customers, salesreps, regions):
        _dim["id"] = _to_str_id(_dim["id"])

    # Coerce SALES FKs to string (safe now that we have exactly one column for each FK)
    for fk in ("product_id", "customer_id", "sales_rep_id", "region_id"):
        sales[fk] = _to_str_id(sales[fk])

    # If opportunities exist, coerce their FKs too
    if not opp.empty:
        for fk in ("sales_rep_id", "region_id"):
            opp[fk] = _to_str_id(opp[fk])


    # Human-friendly aliases in dims (only if present)
    products  = _alias(products,  {"product name":"product_name", "category":"category", "sub-category":"sub_category"})
    customers = _alias(customers, {"customer name":"customer_name", "segment":"segment"})
    salesreps = _alias(salesreps, {"salesrep name":"rep_name", "rep name":"rep_name"})
    regions   = _alias(regions,   {"region":"region_name"})  # your file already has region_name

    # --- GUARANTEE canonical FKs exist and are unique ---
    for fk, variants in {
        "product_id":   ["product_id", "Product ID", "prod_id"],
        "customer_id":  ["customer_id", "Customer ID", "cust_id"],
        "sales_rep_id": ["sales_rep_id", "SalesRep ID", "salesrep_id", "rep_id"],
        "region_id":    ["region_id", "Region ID", "region"],
    }.items():
        # Find all present variants (case-insensitive)
        matches = [c for c in sales.columns if c.lower() in [v.lower() for v in variants]]
        if len(matches) > 1:
            # Coalesce duplicates and drop extras
            base = matches[0]
            sales[base] = sales[matches].bfill(axis=1).iloc[:, 0]
            for c in matches[1:]:
                sales.drop(columns=c, inplace=True, errors="ignore")
        elif not matches:
            sales[fk] = pd.NA
        # Ensure canonical label
        if fk not in sales.columns:
            sales.rename(columns={matches[0]: fk}, inplace=True)
        elif matches and matches[0] != fk:
            sales.rename(columns={matches[0]: fk}, inplace=True)


    for _dim in (products, customers, salesreps, regions):
        _dim["id"] = _to_str_id(_dim["id"])

    # If regions.csv doesn't have state/city, create them so downstream code is happy
    for col in ("state","city"):
        if col not in regions.columns:
            regions[col] = None



    # ----- normalize sales fact -----
    # Map any variants to our canonical fk names
    sales = _alias(sales, {
        "order date":"order_date",
        "quantity":"quantity",
        "sales":"sales_amount",
        "discount":"discount",
        "profit":"profit",
        "product id":"product_id",
        "customer id":"customer_id",
        "salesrep id":"sales_rep_id",
        "rep_id":"sales_rep_id",
        "region id":"region_id"
    })




    # --- Coalesce SALES FK synonyms into single canonical columns ---
    # We accept multiple feeds: "product id", "prod_id", "product_id" etc.
    sales = _coalesce_to(
        sales, "product_id",
        ["product_id", "product id", "prod_id", "sku", "item_id"]
    )
    sales = _coalesce_to(
        sales, "customer_id",
        ["customer_id", "customer id", "cust_id", "client_id"]
    )
    sales = _coalesce_to(
        sales, "sales_rep_id",
        ["sales_rep_id", "salesrep id", "salesrep_id", "rep_id", "sales rep id"]
    )
    sales = _coalesce_to(
        sales, "region_id",
        ["region_id", "region id", "region"]   # if only 'region' exists, we'll treat it as an id-like key
    )

    # If any is still missing, create it (prevents KeyError in merges)
    for fk in ("product_id", "customer_id", "sales_rep_id", "region_id"):
        if fk not in sales.columns:
            sales[fk] = pd.NA

    sales = _ensure_col(sales, "product_id",   ["product_id", "Product ID", "prod_id"])
    sales = _ensure_col(sales, "customer_id",  ["customer_id", "Customer ID", "cust_id"])
    sales = _ensure_col(sales, "sales_rep_id", ["sales_rep_id", "SalesRep ID", "salesrep_id", "rep_id"])
    sales = _ensure_col(sales, "region_id",    ["region_id", "Region ID", "region"])
    for _dim in (products, customers, salesreps, regions):
        _dim["id"] = _to_str_id(_dim["id"])

# Coalesce duplicated columns created by renames (e.g., 'Region ID' -> 'region_id' while 'region_id' already existed)
    if sales.columns.duplicated().any():
        for col in pd.Index(sales.columns)[sales.columns.duplicated()].unique():
            dup_cols = [c for c in sales.columns if c == col]
            # take first non-null across duplicates, then keep a single column
            sales[col] = sales[dup_cols].bfill(axis=1).iloc[:, 0]
            sales = sales.loc[:, ~sales.columns.duplicated()]

    # Ensure FK columns exist before we touch them (avoid KeyError)
    for fk in ["product_id", "customer_id", "sales_rep_id", "region_id"]:
        if fk not in sales.columns:
            sales[fk] = pd.NA

    # Coerce FKs to clean string IDs
    for fk in ["product_id", "customer_id", "sales_rep_id", "region_id"]:
        sales[fk] = _to_str_id(sales[fk])

    # Numerics (optional columns are ok)
    for col in ["sales_amount", "quantity", "discount", "profit"]:
        if col in sales.columns:
            sales[col] = _to_num(sales[col]).fillna(0)

    # Build SalesSummary-like frame (all left joins, tolerant)
    sales_summary = (
        sales
        .merge(products,  left_on="product_id",    right_on="id", how="left", suffixes=("","_p"))
        .merge(customers, left_on="customer_id",   right_on="id", how="left", suffixes=("","_c"))
        .merge(salesreps, left_on="sales_rep_id",  right_on="id", how="left", suffixes=("","_sr"))
        .merge(regions,   left_on="region_id",     right_on="id", how="left", suffixes=("","_r"))
    )

    # Columns the tools expect (create missing ones then select)
    needed = [
        "order_date","quantity","sales_amount","discount","profit",
        "product_name","category","sub_category",
        "customer_name","segment",
        "rep_name",
        "region_name","state","city",
    ]
    for col in needed:
        if col not in sales_summary.columns:
            sales_summary[col] = None
    sales_summary = sales_summary[needed]

    # ----- OpportunitySummary-like (optional) -----
    opp_summary = pd.DataFrame()
    if not opp.empty:
        opp = _alias(opp, {
            "created date":"created_date",
            "stage":"stage",
            "probability":"probability",
            "amount":"deal_amount",
            "salesrep id":"sales_rep_id",
            "rep_id":"sales_rep_id",
            "region id":"region_id"
        })
    # --- Coalesce OPPORTUNITY FK synonyms (if opportunities present) ---
    if not opp.empty:
        opp = _coalesce_to(
            opp, "sales_rep_id",
            ["sales_rep_id", "salesrep id", "salesrep_id", "rep_id", "sales rep id"]
        )
        opp = _coalesce_to(
            opp, "region_id",
            ["region_id", "region id", "region"]
        )
        for fk in ("sales_rep_id", "region_id"):
            if fk not in opp.columns:
                opp[fk] = pd.NA

        opp = _ensure_col(opp, "sales_rep_id", ["sales_rep_id", "SalesRep ID", "salesrep_id", "rep_id"])
        opp = _ensure_col(opp, "region_id",    ["region_id", "Region ID", "region"])

        for fk in ["sales_rep_id", "region_id"]:
            if fk not in opp.columns:
                opp[fk] = pd.NA
        opp["sales_rep_id"] = _to_str_id(opp["sales_rep_id"])
        opp["region_id"]    = _to_str_id(opp["region_id"])

        opp_summary = (
            opp
            .merge(salesreps, left_on="sales_rep_id", right_on="id", how="left")
            .merge(regions,   left_on="region_id",    right_on="id", how="left")
        )
        need_opp = ["created_date","stage","probability","deal_amount","rep_name","region_name","state","city"]
        for c in need_opp:
            if c not in opp_summary.columns:
                opp_summary[c] = None
        opp_summary = opp_summary[need_opp]

    return sales_summary, opp_summary
# ---------------------------
# Filter normalization (fail-soft)
# ---------------------------

def _as_list_loader(x):
    if x is None or x == "" or x == []:
        return []
    if isinstance(x, (list, tuple, set)):
        return list(x)
    if isinstance(x, dict):
        return []
    return [x]

def _normalize_filters_for_loader(filters: dict | None) -> dict:
    f = filters.copy() if isinstance(filters, dict) else {}
    f["regions"]    = _as_list_loader(f.get("regions"))
    f["reps"]       = _as_list_loader(f.get("reps"))
    f["categories"] = _as_list_loader(f.get("categories"))
    return f

# ---------------------------
# Public loader API
# ---------------------------

def load_frames(filters: Optional[Dict[str, Any]] = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
    if os.getenv("USE_CSV_LOADER","0") == "1":
        base_dir = os.getenv("CSV_BASE_DIR") or os.path.join(os.getcwd(), "backend","database","data","processed")
        sales_df, opp_df = _load_from_csv(base_dir)
    else:
        engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True)
        sales_sql = os.getenv("ANALYTICS_SQL_SALES", "").strip() or f"SELECT * FROM {DEFAULT_SALES_VIEW}"
        opp_sql   = os.getenv("ANALYTICS_SQL_OPP", "").strip()   or f"SELECT * FROM {DEFAULT_OPP_VIEW}"
        sales_df = _read_sql(engine, sales_sql)
        try:
            opp_df = _read_sql(engine, opp_sql)
        except Exception:
            opp_df = pd.DataFrame()


    # --- normalize filters to what apply_filters expects ---
    def _norm_list(x):
        if x is None:
            return None
        if isinstance(x, (list, tuple, set)):
            return list(x)
        # treat single string as a single-choice list
        return [x]

    def _norm_filters(f: Dict[str, Any] | None) -> Dict[str, Any]:
        f = dict(f or {})
        # date defaults: whole range if not provided
        if not f.get("date_from") and "order_date" in sales_df.columns and not sales_df.empty:
            f["date_from"] = pd.to_datetime(sales_df["order_date"], errors="coerce").min().date()
        if not f.get("date_to") and "order_date" in sales_df.columns and not sales_df.empty:
            f["date_to"] = pd.to_datetime(sales_df["order_date"], errors="coerce").max().date()
        # lists
        for k in ("regions", "reps", "categories"):
            if k in f:
                f[k] = _norm_list(f[k])
        return f


    # Optional preprocessing/filters (fail-soft)
    try:
        from app.utils.data_functions import preprocess, apply_filters  # type: ignore
        norm_filters = _normalize_filters_for_loader(filters)

        if not sales_df.empty:
            sales_df = preprocess(sales_df)
            nf = _norm_filters(filters)
            sales_df = apply_filters(sales_df, nf.get("date_from"), nf.get("date_to"),
                                    nf.get("regions"), nf.get("reps"), nf.get("categories"))
        if not opp_df.empty:
            opp_df = preprocess(opp_df)
            nf = _norm_filters(filters)
            opp_df = apply_filters(opp_df, nf.get("date_from"), nf.get("date_to"),
                                   nf.get("regions"), nf.get("reps"), nf.get("categories"))



    except Exception:
        pass

    return sales_df, opp_df

def load_dataframe_for_tool(tool_name: str, filters: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
    sales_df, opp_df = load_frames(filters)
    lname = tool_name.lower()
    if "opportunity" in lname or lname.startswith("pipeline"):
        return opp_df if not opp_df.empty else sales_df
    return sales_df
